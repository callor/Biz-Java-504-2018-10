using System;
using System.Collections.Generic;
using System.Text;

namespace TextDiary
{
    public enum NowText
    {
        ExternalFile = -4,
        File = -3,
        Folder = -2,
        Null = -1,
        Categori0 = 0,
        Categori1,
        Categori2,
        Categori3,
        Categori4
    }
}
