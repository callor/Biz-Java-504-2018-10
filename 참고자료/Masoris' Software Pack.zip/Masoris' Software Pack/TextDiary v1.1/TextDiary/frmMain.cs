using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Threading;

namespace TextDiary
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //���� �ʱ�ȭ
            RefreshAll();
        }





        //treeView ���� �ҷ�����
        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //���� ���� ����
            SaveTextFile();
            StandardAllButton();

            try
            {
                //�������� ����
                if (!collapsing)
                {
                    e.Node.Expand();
                }
                collapsing = false;

                //�������� ����

                //�ҷ�����
                if (e.Node.ImageIndex == 0)
                {
                    NowText = NowText.Folder;
                    LoadTextFile(String.Format("{0}\\{1}", e.Node.FullPath, Setting.FolderCommentFile));
                }
                if (e.Node.ImageIndex == 2)
                {
                    StandardAllButton();
                    LoadTextFile(e.Node.FullPath);
                }
            }
            catch { }
        }






        private void btnCate0_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            this.NowText = NowText.Categori0;
            LoadTextDate();
        }

        private void btnCate1_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            this.NowText = NowText.Categori1;
            LoadTextDate();
        }

        private void btnCate2_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            this.NowText = NowText.Categori2;
            LoadTextDate();
        }

        private void btnCate3_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            this.NowText = NowText.Categori3;
            LoadTextDate();
        }

        private void btnCate4_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            this.NowText = NowText.Categori4;
            LoadTextDate();
        }

        private void btnRefrash_Click(object sender, EventArgs e)
        {
            RefreshTree();
            RefreshBoiledDates();
            EmphasisCategori();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveTextFile();
        }

        private void tsmAddText_Click(object sender, EventArgs e)
        {
            TreeNode treeNode;
            //�߰��� ���� ����
            if (treeView.SelectedNode.ImageIndex == 0)
                treeNode = treeView.SelectedNode;
            else
                treeNode = treeView.SelectedNode.Parent;

            //�߰��� ���ϸ� ã��
            bool exist = true;
            string fileName = "";
            string fullPath = "";
            int count = 1;
            while (exist)
            {
                fileName = String.Format(Language.NewTextName, (count++).ToString());
                fullPath = treeNode.FullPath + "\\" + fileName;
                exist = File.Exists(fullPath);
            }

            treeNode.Nodes.Add(new TreeNode(fileName, 2, 3));
            File.Create(fullPath);
        }

        string beforePath;
        private void treeView_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            lock (this)
            {
                //�ֻ��� ����ϰ�� ��������
                foreach (TreeNode treenode in treeView.Nodes)
                {
                    if (treenode == e.Node)
                    {
                        e.CancelEdit = true;
                        return;
                    }
                }

                //�󺧸��� ������ ��������
                if (e.Label == "" || e.Label == null)
                    return;

                //�̸� ����
                try
                {
                    if (e.Node.ImageIndex == 0)
                        Directory.Move(e.Node.FullPath, e.Label);
                    if (e.Node.ImageIndex == 2)
                    {
                        string afterPath = e.Label;
                        if (Setting.HideExtension)
                        {
                            beforePath = GetFullPath(beforePath);
                            string extension = Path.GetExtension(beforePath);
                            string dirPath = Path.GetDirectoryName(beforePath);
                            afterPath = dirPath + "\\" + afterPath + extension;
                        }
                        File.Move(beforePath, afterPath);

                        filePath = afterPath;
                    }
                }
                catch
                {
                    e.CancelEdit = true;
                }
            }
        }
        private void treeView_BeforeLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            SaveTextFile();
            beforePath = e.Node.FullPath;
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void tsbRefresh_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            RefreshTree();
            RefreshBoiledDates();
            EmphasisCategori();
        }

        private void tsbAddText_Click(object sender, EventArgs e)
        {

            SaveTextFile();
            TreeNode treeNode;
            //�߰��� ���� ����
            try
            {
                if (treeView.SelectedNode.ImageIndex == 0)
                    treeNode = treeView.SelectedNode;
                else
                    treeNode = treeView.SelectedNode.Parent;
            }
            catch
            {
                return;
            }

            //�߰��� ���ϸ� ã��
            bool exist = true;
            string fileName = "";
            string fullPath = "";
            int count = 1;
            while (exist)
            {
                fileName = String.Format(Language.NewTextName, (count++).ToString());
                fullPath = treeNode.FullPath + "\\" + fileName;
                exist = File.Exists(fullPath);
            }

            //���� ����
            StreamWriter sw = new StreamWriter(fullPath, true);
            sw.Flush();
            sw.Close();

            //����߰�
            TreeNode node;
            if (Setting.HideExtension)
                node = new TreeNode(Path.GetFileNameWithoutExtension(fileName), 2, 3);
            else
                node = new TreeNode(fileName, 2, 3);
            treeNode.Nodes.Add(node);
            fileName = fullPath;

            //Node ��ġ���� ����
            treeNode.Expand();
            node.BeginEdit();
        }

        private void tsbAddFolder_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            TreeNode treeNode;
            //�߰��� ���� ����
            try
            {
                if (treeView.SelectedNode.ImageIndex == 0)
                    treeNode = treeView.SelectedNode;
                else
                    treeNode = treeView.SelectedNode.Parent;
            }
            catch
            {
                return;
            }

            //�߰��� ������ ã��
            bool exist = true;
            string folderName = "";
            string fullPath = "";
            int count = 1;
            while (exist)
            {
                folderName = String.Format(Language.NewFolderName, (count++).ToString());
                fullPath = treeNode.FullPath + "\\" + folderName;
                exist = Directory.Exists(fullPath);
            }

            //�߰�
            TreeNode node = new TreeNode(folderName, 0, 1);
            treeNode.Nodes.Add(node);
            Directory.CreateDirectory(fullPath);

            //Node ��ġ���� ����
            treeNode.Expand();
            node.BeginEdit();



        }

        private void tsbRemove_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            //�ֻ��� ����ϰ�� ��������
            foreach (TreeNode treenode in treeView.Nodes)
            {
                if (treenode == treeView.SelectedNode)
                {
                    return;
                }
            }

            //����
            try
            {
                if (treeView.SelectedNode.ImageIndex == 0)
                {
                    DialogResult result =
                        MessageBox.Show(
                        String.Format(Language.Message_Remove, treeView.SelectedNode.Text),
                        Language.Tree_Remove, MessageBoxButtons.OKCancel);
                    if (result == DialogResult.OK)
                    {
                        //Directory.Delete(treeView.SelectedNode.FullPath, true);
                        FileSystem.DeleteDirectory(treeView.SelectedNode.FullPath, UIOption.AllDialogs, RecycleOption);
                        treeView.SelectedNode.Remove();
                    }
                }
                if (treeView.SelectedNode.ImageIndex == 2)
                {
                    string path = treeView.SelectedNode.FullPath;
                    if (Setting.HideExtension)
                        path = GetFullPath(path);
                    //File.Delete(path);
                    FileSystem.DeleteFile(path, UIOption.OnlyErrorDialogs, RecycleOption);
                    nowText = NowText.Null;
                    treeView.SelectedNode.Remove();
                }

            }
            catch
            {
            }
        }

        private void tsbRename_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            //�ֻ��� ����ϰ�� ��������
            foreach (TreeNode treenode in treeView.Nodes)
            {
                if (treenode == treeView.SelectedNode)
                {
                    return;
                }
            }

            treeView.SelectedNode.BeginEdit();

        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            //���� ���� ����
            SaveTextFile();

            //����â ����
            frmSetting form = new frmSetting();
            form.frmMain = this;
            form.ShowDialog();
        }

        private void tsmi_Undo_Click(object sender, EventArgs e)
        {
            rtbText.Undo();
        }

        private void tsmi_Cut_Click(object sender, EventArgs e)
        {
            rtbText.Cut();
        }

        private void tsmi_Copy_Click(object sender, EventArgs e)
        {
            rtbText.Copy();
        }

        private void tsmi_Paste_Click(object sender, EventArgs e)
        {
            rtbText.Paste();
        }

        private void tsmi_Delete_Click(object sender, EventArgs e)
        {
            rtbText.SelectedText = "";
        }

        private void tsmi_SelectAll_Click(object sender, EventArgs e)
        {
            rtbText.SelectAll();
        }

        private void tsmi_LoadAgain_Click(object sender, EventArgs e)
        {
            LoadTextFile(filePath);
        }

        private void treeView_Enter(object sender, EventArgs e)
        {
            TreeViewEventArgs te = new TreeViewEventArgs(treeView.SelectedNode);
            treeView_AfterSelect(this, te);
        }

        private void treeView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                treeView.SelectedNode = e.Node;
        }

        private void tsmiNewText_Click(object sender, EventArgs e)
        {
            tsbAddText_Click(sender, e);
        }

        private void tsmiNewFolder_Click(object sender, EventArgs e)
        {
            tsbAddFolder_Click(sender, e);
        }

        private void tsmiEdit_Click(object sender, EventArgs e)
        {
            tsbRename_Click(sender, e);
        }

        private void tsmiRemove_Click(object sender, EventArgs e)
        {
            tsbRemove_Click(sender, e);
        }

        private void tsmiRefresh_Click(object sender, EventArgs e)
        {
            tsbRefresh_Click(sender, e);
        }

        private void tsmiRun_Click(object sender, EventArgs e)
        {
            SaveTextFile();
            string path = treeView.SelectedNode.FullPath;
            if (Setting.HideExtension && treeView.SelectedNode.ImageIndex == 2)
                path = GetFullPath(path);
            System.Diagnostics.Process.Start(path);
        }

        bool collapsing = false;
        private void treeView_BeforeCollapse(object sender, TreeViewCancelEventArgs e)
        {
            collapsing = true;
        }

        private void calendar_MouseDown(object sender, MouseEventArgs e)
        {
            SaveTextFile();
            LoadTextDate();
            EmphasisCategori();
            //RefreshBoiledDates();
        }


        #region "Drag and Drop"

        

        private void treeView_MouseDown(object sender, MouseEventArgs e)
        {
            //TreeNode DragingNode;
            //DragingNode = treeView.GetNodeAt(e.X, e.Y);
            //treeView.SelectedNode = DragingNode;
            //DoDragDrop(DragingNode, DragDropEffects.All); 
        }

        private void treeView_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void treeView_DragDrop(object sender, DragEventArgs e)
        {
            Point pt = new Point(e.X, e.Y);
            pt = treeView.PointToClient(pt);
            TreeNode DragingNode;
            TreeNode TargetNode = treeView.GetNodeAt(pt);

            if (e.Data.GetDataPresent("System.Windows.Forms.TreeNode", false))
            {
                DragingNode = (TreeNode)e.Data.GetData("System.Windows.Forms.TreeNode", false);
                TargetNode.Nodes.Add(DragingNode);
                DragingNode.Remove();
            }

            

        }

        #endregion

        private void rtbText_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.LinkText);
        }

        private void calendar_DateChanged(object sender, DateRangeEventArgs e)
        {
        }

        private void btnRemoveCurrentFile_Click(object sender, EventArgs e)
        {
            DialogResult result =
    MessageBox.Show(
    String.Format(Language.Message_Remove, Path.GetFileName(filePath)),
    Language.Tree_Remove, MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                try
                {
                    string path = filePath;
                    FileSystem.DeleteFile(path, UIOption.OnlyErrorDialogs, RecycleOption);
                    nowText = NowText.Null;
                    rtbText.Text = null;
                    string treepath = "";
                    try
                    {
                        treepath = GetFullPath(treeView.SelectedNode.FullPath);
                    }
                    catch { }
                    if (treepath == path)
                        treeView.SelectedNode.Remove();
                    else
                        LoadTextFile(path);
                }
                catch { }
            }
        }

        private void timAutoSave_Tick(object sender, EventArgs e)
        {
            SaveTextFile();
        }

        private void cmsText_Opening(object sender, CancelEventArgs e)
        {

        }

        private void tsmi_Print_Click(object sender, EventArgs e)
        {
            printD.Print();
        }



    }
}