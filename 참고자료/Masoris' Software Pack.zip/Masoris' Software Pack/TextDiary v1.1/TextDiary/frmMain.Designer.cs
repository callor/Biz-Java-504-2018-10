﻿namespace TextDiary
{
    partial class frmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.calendar = new System.Windows.Forms.MonthCalendar();
            this.treeView = new System.Windows.Forms.TreeView();
            this.cmsTree = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiNewText = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNewFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiRefresh = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiRun = new System.Windows.Forms.ToolStripMenuItem();
            this.imgListTree = new System.Windows.Forms.ImageList(this.components);
            this.rtbText = new System.Windows.Forms.RichTextBox();
            this.cmsText = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmi_Undo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi_Cut = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Paste = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Delete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmi_SelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_LoadAgain = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi_Print = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTextPath = new System.Windows.Forms.Label();
            this.btnCate0 = new System.Windows.Forms.Button();
            this.btnCate1 = new System.Windows.Forms.Button();
            this.btnCate2 = new System.Windows.Forms.Button();
            this.btnCate3 = new System.Windows.Forms.Button();
            this.btnCate4 = new System.Windows.Forms.Button();
            this.btnSetting = new System.Windows.Forms.Button();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.treeStrip = new System.Windows.Forms.ToolStrip();
            this.tsbAddText = new System.Windows.Forms.ToolStripButton();
            this.tsbAddFolder = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbRename = new System.Windows.Forms.ToolStripButton();
            this.tsbRemove = new System.Windows.Forms.ToolStripButton();
            this.tsbRefresh = new System.Windows.Forms.ToolStripButton();
            this.btnRemoveCurrentFile = new System.Windows.Forms.Button();
            this.timAutoSave = new System.Windows.Forms.Timer(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.printD = new System.Drawing.Printing.PrintDocument();
            this.cmsTree.SuspendLayout();
            this.cmsText.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.treeStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // calendar
            // 
            this.calendar.Location = new System.Drawing.Point(10, 9);
            this.calendar.MaxSelectionCount = 1;
            this.calendar.Name = "calendar";
            this.calendar.TabIndex = 0;
            this.calendar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.calendar_MouseDown);
            this.calendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.calendar_DateChanged);
            // 
            // treeView
            // 
            this.treeView.AllowDrop = true;
            this.treeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView.ContextMenuStrip = this.cmsTree;
            this.treeView.HideSelection = false;
            this.treeView.ImageIndex = 0;
            this.treeView.ImageList = this.imgListTree;
            this.treeView.Indent = 19;
            this.treeView.LabelEdit = true;
            this.treeView.Location = new System.Drawing.Point(10, 176);
            this.treeView.Name = "treeView";
            this.treeView.SelectedImageIndex = 0;
            this.treeView.ShowRootLines = false;
            this.treeView.Size = new System.Drawing.Size(136, 274);
            this.treeView.TabIndex = 1;
            this.treeView.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeView_DragDrop);
            this.treeView.DragOver += new System.Windows.Forms.DragEventHandler(this.treeView_DragOver);
            this.treeView.Enter += new System.EventHandler(this.treeView_Enter);
            this.treeView.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeCollapse);
            this.treeView.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.treeView_AfterLabelEdit);
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            this.treeView.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView_NodeMouseClick);
            this.treeView.BeforeLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.treeView_BeforeLabelEdit);
            this.treeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseDown);
            // 
            // cmsTree
            // 
            this.cmsTree.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiNewText,
            this.tsmiNewFolder,
            this.toolStripSeparator4,
            this.tsmiEdit,
            this.tsmiRemove,
            this.tsmiRefresh,
            this.tsmiRun});
            this.cmsTree.Name = "cmsTree";
            this.cmsTree.Size = new System.Drawing.Size(169, 142);
            // 
            // tsmiNewText
            // 
            this.tsmiNewText.Image = global::TextDiary.Properties.Resources.TextFile;
            this.tsmiNewText.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmiNewText.Name = "tsmiNewText";
            this.tsmiNewText.Size = new System.Drawing.Size(168, 22);
            this.tsmiNewText.Text = "toolStripMenuItem1";
            this.tsmiNewText.Click += new System.EventHandler(this.tsmiNewText_Click);
            // 
            // tsmiNewFolder
            // 
            this.tsmiNewFolder.Image = global::TextDiary.Properties.Resources.FolderOpened;
            this.tsmiNewFolder.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmiNewFolder.Name = "tsmiNewFolder";
            this.tsmiNewFolder.Size = new System.Drawing.Size(168, 22);
            this.tsmiNewFolder.Text = "toolStripMenuItem1";
            this.tsmiNewFolder.Click += new System.EventHandler(this.tsmiNewFolder_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(165, 6);
            // 
            // tsmiEdit
            // 
            this.tsmiEdit.Image = global::TextDiary.Properties.Resources.Rename;
            this.tsmiEdit.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmiEdit.Name = "tsmiEdit";
            this.tsmiEdit.Size = new System.Drawing.Size(168, 22);
            this.tsmiEdit.Text = "toolStripMenuItem1";
            this.tsmiEdit.Click += new System.EventHandler(this.tsmiEdit_Click);
            // 
            // tsmiRemove
            // 
            this.tsmiRemove.Image = global::TextDiary.Properties.Resources.Remove;
            this.tsmiRemove.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmiRemove.Name = "tsmiRemove";
            this.tsmiRemove.Size = new System.Drawing.Size(168, 22);
            this.tsmiRemove.Text = "toolStripMenuItem2";
            this.tsmiRemove.Click += new System.EventHandler(this.tsmiRemove_Click);
            // 
            // tsmiRefresh
            // 
            this.tsmiRefresh.Image = global::TextDiary.Properties.Resources.Refresh;
            this.tsmiRefresh.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmiRefresh.Name = "tsmiRefresh";
            this.tsmiRefresh.Size = new System.Drawing.Size(168, 22);
            this.tsmiRefresh.Text = "toolStripMenuItem3";
            this.tsmiRefresh.Click += new System.EventHandler(this.tsmiRefresh_Click);
            // 
            // tsmiRun
            // 
            this.tsmiRun.Image = global::TextDiary.Properties.Resources.Run;
            this.tsmiRun.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmiRun.Name = "tsmiRun";
            this.tsmiRun.Size = new System.Drawing.Size(168, 22);
            this.tsmiRun.Text = "toolStripMenuItem4";
            this.tsmiRun.Click += new System.EventHandler(this.tsmiRun_Click);
            // 
            // imgListTree
            // 
            this.imgListTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgListTree.ImageStream")));
            this.imgListTree.TransparentColor = System.Drawing.Color.Black;
            this.imgListTree.Images.SetKeyName(0, "");
            this.imgListTree.Images.SetKeyName(1, "");
            this.imgListTree.Images.SetKeyName(2, "");
            this.imgListTree.Images.SetKeyName(3, "");
            // 
            // rtbText
            // 
            this.rtbText.AcceptsTab = true;
            this.rtbText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbText.ContextMenuStrip = this.cmsText;
            this.rtbText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbText.Location = new System.Drawing.Point(9, 25);
            this.rtbText.Name = "rtbText";
            this.rtbText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.rtbText.Size = new System.Drawing.Size(571, 422);
            this.rtbText.TabIndex = 1;
            this.rtbText.Text = "";
            this.rtbText.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.rtbText_LinkClicked);
            // 
            // cmsText
            // 
            this.cmsText.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi_Undo,
            this.toolStripSeparator1,
            this.tsmi_Cut,
            this.tsmi_Copy,
            this.tsmi_Paste,
            this.tsmi_Delete,
            this.toolStripSeparator3,
            this.tsmi_SelectAll,
            this.tsmi_LoadAgain,
            this.tsmi_Print});
            this.cmsText.Name = "cmsText";
            this.cmsText.Size = new System.Drawing.Size(169, 214);
            this.cmsText.Opening += new System.ComponentModel.CancelEventHandler(this.cmsText_Opening);
            // 
            // tsmi_Undo
            // 
            this.tsmi_Undo.Image = ((System.Drawing.Image)(resources.GetObject("tsmi_Undo.Image")));
            this.tsmi_Undo.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_Undo.Name = "tsmi_Undo";
            this.tsmi_Undo.Size = new System.Drawing.Size(168, 22);
            this.tsmi_Undo.Text = "toolStripMenuItem1";
            this.tsmi_Undo.Click += new System.EventHandler(this.tsmi_Undo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(165, 6);
            // 
            // tsmi_Cut
            // 
            this.tsmi_Cut.Image = global::TextDiary.Properties.Resources.Cut;
            this.tsmi_Cut.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_Cut.Name = "tsmi_Cut";
            this.tsmi_Cut.Size = new System.Drawing.Size(168, 22);
            this.tsmi_Cut.Text = "toolStripMenuItem1";
            this.tsmi_Cut.Click += new System.EventHandler(this.tsmi_Cut_Click);
            // 
            // tsmi_Copy
            // 
            this.tsmi_Copy.Image = global::TextDiary.Properties.Resources.Copy;
            this.tsmi_Copy.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_Copy.Name = "tsmi_Copy";
            this.tsmi_Copy.Size = new System.Drawing.Size(168, 22);
            this.tsmi_Copy.Text = "toolStripMenuItem2";
            this.tsmi_Copy.Click += new System.EventHandler(this.tsmi_Copy_Click);
            // 
            // tsmi_Paste
            // 
            this.tsmi_Paste.Image = ((System.Drawing.Image)(resources.GetObject("tsmi_Paste.Image")));
            this.tsmi_Paste.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_Paste.Name = "tsmi_Paste";
            this.tsmi_Paste.Size = new System.Drawing.Size(168, 22);
            this.tsmi_Paste.Text = "toolStripMenuItem3";
            this.tsmi_Paste.Click += new System.EventHandler(this.tsmi_Paste_Click);
            // 
            // tsmi_Delete
            // 
            this.tsmi_Delete.Image = ((System.Drawing.Image)(resources.GetObject("tsmi_Delete.Image")));
            this.tsmi_Delete.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_Delete.Name = "tsmi_Delete";
            this.tsmi_Delete.Size = new System.Drawing.Size(168, 22);
            this.tsmi_Delete.Text = "toolStripMenuItem4";
            this.tsmi_Delete.Click += new System.EventHandler(this.tsmi_Delete_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(165, 6);
            // 
            // tsmi_SelectAll
            // 
            this.tsmi_SelectAll.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_SelectAll.Name = "tsmi_SelectAll";
            this.tsmi_SelectAll.Size = new System.Drawing.Size(168, 22);
            this.tsmi_SelectAll.Text = "toolStripMenuItem5";
            this.tsmi_SelectAll.Click += new System.EventHandler(this.tsmi_SelectAll_Click);
            // 
            // tsmi_LoadAgain
            // 
            this.tsmi_LoadAgain.Image = global::TextDiary.Properties.Resources.Refresh;
            this.tsmi_LoadAgain.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_LoadAgain.Name = "tsmi_LoadAgain";
            this.tsmi_LoadAgain.Size = new System.Drawing.Size(168, 22);
            this.tsmi_LoadAgain.Text = "toolStripMenuItem1";
            this.tsmi_LoadAgain.Click += new System.EventHandler(this.tsmi_LoadAgain_Click);
            // 
            // tsmi_Print
            // 
            this.tsmi_Print.Image = global::TextDiary.Properties.Resources.Print;
            this.tsmi_Print.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsmi_Print.Name = "tsmi_Print";
            this.tsmi_Print.Size = new System.Drawing.Size(168, 22);
            this.tsmi_Print.Text = "toolStripMenuItem1";
            this.tsmi_Print.Visible = false;
            this.tsmi_Print.Click += new System.EventHandler(this.tsmi_Print_Click);
            // 
            // lblTextPath
            // 
            this.lblTextPath.AutoSize = true;
            this.lblTextPath.Location = new System.Drawing.Point(6, 9);
            this.lblTextPath.Name = "lblTextPath";
            this.lblTextPath.Size = new System.Drawing.Size(61, 13);
            this.lblTextPath.TabIndex = 0;
            this.lblTextPath.Text = "Label_Path";
            // 
            // btnCate0
            // 
            this.btnCate0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCate0.Location = new System.Drawing.Point(9, 453);
            this.btnCate0.Name = "btnCate0";
            this.btnCate0.Size = new System.Drawing.Size(75, 27);
            this.btnCate0.TabIndex = 2;
            this.btnCate0.Text = "Main_Cate1";
            this.btnCate0.UseVisualStyleBackColor = true;
            this.btnCate0.Click += new System.EventHandler(this.btnCate0_Click);
            // 
            // btnCate1
            // 
            this.btnCate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCate1.Location = new System.Drawing.Point(90, 453);
            this.btnCate1.Name = "btnCate1";
            this.btnCate1.Size = new System.Drawing.Size(75, 27);
            this.btnCate1.TabIndex = 3;
            this.btnCate1.Text = "Main_Cate2";
            this.btnCate1.UseVisualStyleBackColor = true;
            this.btnCate1.Click += new System.EventHandler(this.btnCate1_Click);
            // 
            // btnCate2
            // 
            this.btnCate2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCate2.Location = new System.Drawing.Point(171, 453);
            this.btnCate2.Name = "btnCate2";
            this.btnCate2.Size = new System.Drawing.Size(75, 27);
            this.btnCate2.TabIndex = 4;
            this.btnCate2.Text = "Main_Cate3";
            this.btnCate2.UseVisualStyleBackColor = true;
            this.btnCate2.Click += new System.EventHandler(this.btnCate2_Click);
            // 
            // btnCate3
            // 
            this.btnCate3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCate3.Location = new System.Drawing.Point(252, 453);
            this.btnCate3.Name = "btnCate3";
            this.btnCate3.Size = new System.Drawing.Size(75, 27);
            this.btnCate3.TabIndex = 5;
            this.btnCate3.Text = "Main_Cate4";
            this.btnCate3.UseVisualStyleBackColor = true;
            this.btnCate3.Click += new System.EventHandler(this.btnCate3_Click);
            // 
            // btnCate4
            // 
            this.btnCate4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCate4.Location = new System.Drawing.Point(333, 453);
            this.btnCate4.Name = "btnCate4";
            this.btnCate4.Size = new System.Drawing.Size(75, 27);
            this.btnCate4.TabIndex = 6;
            this.btnCate4.Text = "Main_Cate5";
            this.btnCate4.UseVisualStyleBackColor = true;
            this.btnCate4.Click += new System.EventHandler(this.btnCate4_Click);
            // 
            // btnSetting
            // 
            this.btnSetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetting.Location = new System.Drawing.Point(472, 453);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(75, 27);
            this.btnSetting.TabIndex = 7;
            this.btnSetting.Text = "Main_Setting";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // splitContainer
            // 
            this.splitContainer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.calendar);
            this.splitContainer.Panel1.Controls.Add(this.treeView);
            this.splitContainer.Panel1.Controls.Add(this.treeStrip);
            this.splitContainer.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            this.splitContainer.Panel1MinSize = 154;
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.btnRemoveCurrentFile);
            this.splitContainer.Panel2.Controls.Add(this.rtbText);
            this.splitContainer.Panel2.Controls.Add(this.btnCate4);
            this.splitContainer.Panel2.Controls.Add(this.btnSetting);
            this.splitContainer.Panel2.Controls.Add(this.btnCate3);
            this.splitContainer.Panel2.Controls.Add(this.btnCate2);
            this.splitContainer.Panel2.Controls.Add(this.btnCate1);
            this.splitContainer.Panel2.Controls.Add(this.btnCate0);
            this.splitContainer.Panel2.Controls.Add(this.lblTextPath);
            this.splitContainer.Size = new System.Drawing.Size(754, 491);
            this.splitContainer.SplitterDistance = 157;
            this.splitContainer.TabIndex = 0;
            // 
            // treeStrip
            // 
            this.treeStrip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.treeStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.treeStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAddText,
            this.tsbAddFolder,
            this.toolStripSeparator2,
            this.tsbRename,
            this.tsbRemove,
            this.tsbRefresh});
            this.treeStrip.Location = new System.Drawing.Point(9, 453);
            this.treeStrip.Name = "treeStrip";
            this.treeStrip.Size = new System.Drawing.Size(133, 25);
            this.treeStrip.TabIndex = 2;
            this.treeStrip.Text = "toolStrip1";
            // 
            // tsbAddText
            // 
            this.tsbAddText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddText.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddText.Image")));
            this.tsbAddText.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsbAddText.Name = "tsbAddText";
            this.tsbAddText.Size = new System.Drawing.Size(23, 22);
            this.tsbAddText.Text = "Strip_AddText";
            this.tsbAddText.Click += new System.EventHandler(this.tsbAddText_Click);
            // 
            // tsbAddFolder
            // 
            this.tsbAddFolder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAddFolder.Image = ((System.Drawing.Image)(resources.GetObject("tsbAddFolder.Image")));
            this.tsbAddFolder.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsbAddFolder.Name = "tsbAddFolder";
            this.tsbAddFolder.Size = new System.Drawing.Size(23, 22);
            this.tsbAddFolder.Text = "Strip_AddFolder";
            this.tsbAddFolder.Click += new System.EventHandler(this.tsbAddFolder_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbRename
            // 
            this.tsbRename.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRename.Image = ((System.Drawing.Image)(resources.GetObject("tsbRename.Image")));
            this.tsbRename.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsbRename.Name = "tsbRename";
            this.tsbRename.Size = new System.Drawing.Size(23, 22);
            this.tsbRename.Text = "Strip_Rename";
            this.tsbRename.Click += new System.EventHandler(this.tsbRename_Click);
            // 
            // tsbRemove
            // 
            this.tsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRemove.Image = ((System.Drawing.Image)(resources.GetObject("tsbRemove.Image")));
            this.tsbRemove.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsbRemove.Name = "tsbRemove";
            this.tsbRemove.Size = new System.Drawing.Size(23, 22);
            this.tsbRemove.Text = "Strip_Remove";
            this.tsbRemove.Click += new System.EventHandler(this.tsbRemove_Click);
            // 
            // tsbRefresh
            // 
            this.tsbRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRefresh.Image = ((System.Drawing.Image)(resources.GetObject("tsbRefresh.Image")));
            this.tsbRefresh.ImageTransparentColor = System.Drawing.Color.Black;
            this.tsbRefresh.Name = "tsbRefresh";
            this.tsbRefresh.Size = new System.Drawing.Size(23, 22);
            this.tsbRefresh.Text = "Strip_Refresh";
            this.tsbRefresh.Click += new System.EventHandler(this.tsbRefresh_Click);
            // 
            // btnRemoveCurrentFile
            // 
            this.btnRemoveCurrentFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRemoveCurrentFile.Image = ((System.Drawing.Image)(resources.GetObject("btnRemoveCurrentFile.Image")));
            this.btnRemoveCurrentFile.Location = new System.Drawing.Point(553, 453);
            this.btnRemoveCurrentFile.Name = "btnRemoveCurrentFile";
            this.btnRemoveCurrentFile.Size = new System.Drawing.Size(27, 27);
            this.btnRemoveCurrentFile.TabIndex = 8;
            this.btnRemoveCurrentFile.UseVisualStyleBackColor = true;
            this.btnRemoveCurrentFile.Click += new System.EventHandler(this.btnRemoveCurrentFile_Click);
            // 
            // timAutoSave
            // 
            this.timAutoSave.Interval = 10000;
            this.timAutoSave.Tick += new System.EventHandler(this.timAutoSave_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 491);
            this.Controls.Add(this.splitContainer);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Main_TitleName";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.cmsTree.ResumeLayout(false);
            this.cmsText.ResumeLayout(false);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            this.splitContainer.ResumeLayout(false);
            this.treeStrip.ResumeLayout(false);
            this.treeStrip.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MonthCalendar calendar;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.RichTextBox rtbText;
        private System.Windows.Forms.Label lblTextPath;
        private System.Windows.Forms.Button btnCate0;
        private System.Windows.Forms.Button btnCate1;
        private System.Windows.Forms.Button btnCate2;
        private System.Windows.Forms.Button btnCate3;
        private System.Windows.Forms.Button btnCate4;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.ImageList imgListTree;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.ToolStrip treeStrip;
        private System.Windows.Forms.ToolStripButton tsbAddText;
        private System.Windows.Forms.ToolStripButton tsbAddFolder;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbRename;
        private System.Windows.Forms.ToolStripButton tsbRemove;
        private System.Windows.Forms.ToolStripButton tsbRefresh;
        private System.Windows.Forms.ContextMenuStrip cmsText;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Undo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Cut;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Copy;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Paste;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Delete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem tsmi_SelectAll;
        private System.Windows.Forms.ToolStripMenuItem tsmi_LoadAgain;
        private System.Windows.Forms.ContextMenuStrip cmsTree;
        private System.Windows.Forms.ToolStripMenuItem tsmiNewText;
        private System.Windows.Forms.ToolStripMenuItem tsmiNewFolder;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem tsmiEdit;
        private System.Windows.Forms.ToolStripMenuItem tsmiRemove;
        private System.Windows.Forms.ToolStripMenuItem tsmiRefresh;
        private System.Windows.Forms.ToolStripMenuItem tsmiRun;
        private System.Windows.Forms.Timer timAutoSave;
        private System.Windows.Forms.Button btnRemoveCurrentFile;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem tsmi_Print;
        private System.Drawing.Printing.PrintDocument printD;
    }
}