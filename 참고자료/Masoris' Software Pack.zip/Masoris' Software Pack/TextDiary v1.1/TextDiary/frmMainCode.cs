using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Threading;

namespace TextDiary
{
    public partial class frmMain
    {
        public Setting Setting;
        public Language Language;
        string filePath; //���� �ؽ�Ʈ ���� ��ġ
        NowText nowText = NowText.Null;
        string TextWhenLoad; //�ε��� �׽�Ʈ
        RecycleOption RecycleOption;
        public NowText NowText
        {
            get
            {
                return nowText;
            }
            set
            {
                nowText = value;

                StandardAllButton();
                if (value == NowText.Categori0)
                    btnCate0.FlatStyle = FlatStyle.Flat;
                else
                    btnCate0.FlatStyle = FlatStyle.Standard;

                if (value == NowText.Categori1)
                    btnCate1.FlatStyle = FlatStyle.Flat;
                else
                    btnCate1.FlatStyle = FlatStyle.Standard;

                if (value == NowText.Categori2)
                    btnCate2.FlatStyle = FlatStyle.Flat;
                else
                    btnCate2.FlatStyle = FlatStyle.Standard;

                if (value == NowText.Categori3)
                    btnCate3.FlatStyle = FlatStyle.Flat;
                else
                    btnCate3.FlatStyle = FlatStyle.Standard;

                if (value == NowText.Categori4)
                    btnCate4.FlatStyle = FlatStyle.Flat;
                else
                    btnCate4.FlatStyle = FlatStyle.Standard;
            }
        }

        public void StandardAllButton()
        {
            btnCate0.FlatStyle = FlatStyle.Standard;
            btnCate1.FlatStyle = FlatStyle.Standard;
            btnCate2.FlatStyle = FlatStyle.Standard;
            btnCate3.FlatStyle = FlatStyle.Standard;
            btnCate4.FlatStyle = FlatStyle.Standard;
            btnCate0.Font = new Font(btnCate0.Font, FontStyle.Regular);
            btnCate1.Font = new Font(btnCate0.Font, FontStyle.Regular);
            btnCate2.Font = new Font(btnCate0.Font, FontStyle.Regular);
            btnCate3.Font = new Font(btnCate0.Font, FontStyle.Regular);
            btnCate4.Font = new Font(btnCate0.Font, FontStyle.Regular);
        }

        //TreeView�� �����մϴ�.
        public void RefreshTree()
        {
            treeView.BeginUpdate();

            treeView.Nodes.Clear();
            TreeNode treeNode = new TreeNode(Setting.TreeViewPath, 0, 1);
            treeView.Nodes.Add(treeNode);
            AddDirectories(treeNode);
            treeNode.Expand();
            treeView.Invalidate();

            treeView.EndUpdate();

        }
        //���� Node�߰�
        void AddDirectories(TreeNode TreeNode)
        {
            TreeNode.Nodes.Clear();

            string path = TreeNode.FullPath;
            DirectoryInfo dirInfo = new DirectoryInfo(path);
            DirectoryInfo[] dirInfos;

            try
            {
                dirInfos = dirInfo.GetDirectories();
            }
            catch
            {
                return;
            }

            foreach (DirectoryInfo di in dirInfos)
            {
                TreeNode newNode = new TreeNode(di.Name, 0, 1);
                TreeNode.Nodes.Add(newNode);

                AddDirectories(newNode);
            }

            foreach (string extension in Setting.Extensions)
            {
                foreach (FileInfo fi in dirInfo.GetFiles(extension))
                {
                    if (fi.Name != Setting.FolderCommentFile)
                    {
                        TreeNode newNode;
                        if (Setting.HideExtension)
                        {
                            newNode = new TreeNode(fi.Name.Substring(0, fi.Name.Length - fi.Extension.Length), 2, 3);
                        }
                        else
                        {
                            newNode = new TreeNode(fi.Name, 2, 3);
                        }
                        TreeNode.Nodes.Add(newNode);
                    }
                }
            }
        }

        //�ؽ�Ʈ���� �ؽ�Ʈ�ڽ��� �ҷ�����
        public void LoadTextFile(string Path)
        {
            LoadTextFile(Path, Encoding.Default);
        }
        //�ؽ�Ʈ���� �ؽ�Ʈ�ڽ��� �ҷ�����, +����Ʈ ���ڵ� ���� ����
        public void LoadTextFile(string Path, Encoding encoding)
        {
            //����Ʈ ���ڵ� ����
            TextEncoding.SetDefEncoding(encoding);
            //��ü��� ���
            Path = System.IO.Path.GetFullPath(Path);

            //Ȯ���ڰ� ������ ������, ���� Ȯ���� ã��
            if (Setting.HideExtension)
                Path = GetFullPath(Path);

            //���� ���
            string result;
            try
            {
                result = TextEncoding.ReadTextFile(Path);
                lblTextPath.Text = Path;
            }
            catch
            {
                result = "";
                lblTextPath.Text = String.Format("{0} {1}", Path, Language.Message_NewFile);
            }
            TextWhenLoad = result;
            filePath = Path;
            rtbText.Text = result;

            //calendar ����
            RefreshCalendar();
            EmphasisCategori();
        }

        //�ؽ�Ʈ�ڽ����� �ؽ�Ʈ ���Ϸ� ����
        public void SaveTextFile()
        {
            string path = filePath;

            //�ؽ�Ʈ�� ��ȭ�� ������ �������
            if (rtbText.Text == TextWhenLoad)
                return;

            //���ڵ� ����
            Encoding enco;
            if (Setting.UseDefaultEncoding)
                enco = Encoding.Default;
            else
                enco = Encoding.UTF8;
        //�����̳� ����Comment�� ī�װ����̸� �״�� ����.
        SaveStart: ;
            try
            {
                if (NowText == NowText.File || NowText == NowText.Folder || (0 <= (int)NowText && (int)NowText < Setting.CateLimit))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path));
                    StreamWriter sw = new StreamWriter(path, false, enco);
                    for (int i = 0; i < rtbText.Lines.Length - 1; i++)
                    {
                        sw.WriteLine(rtbText.Lines[i]);
                    }
                    sw.Write(rtbText.Lines[rtbText.Lines.Length - 1]);
                    sw.Close();
                    //�ؽ�Ʈ ����
                    TextWhenLoad = rtbText.Text;
                }
            }
            catch
            {
                DialogResult dialog = MessageBox.Show(Language.Message_SaveError, Language.Message_RaiseError, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                switch (dialog)
                {
                    case DialogResult.Abort:
                        break;
                    case DialogResult.Retry:
                        goto SaveStart;
                    case DialogResult.Ignore:
                        break;
                }
            }
        }

        //Calender���� �ؽ�Ʈ ���� �б�
        public void LoadTextDate()
        {
            if (!(0 <= (int)NowText && (int)NowText < Setting.CateLimit))
            {
                this.NowText = NowText.Categori0;
            }
            DateTime date = calendar.SelectionStart;
            string path = Path.GetFullPath(Setting.CatePath[(int)NowText]);
            string filepath = date.ToString("yyyyMMdd");
            string fullpath = String.Format("{0}\\{1}.{2}", path, filepath, Setting.TextExtension);

            LoadTextFile(fullpath);
        }

        //Calender���� BoiledDates ����
        public void RefreshBoiledDates()
        {
            ArrayList array = new ArrayList();
            foreach (string dirpath in Setting.CatePath)
            {
                try
                {

                    string[] files = Directory.GetFiles(dirpath, "*." + Setting.TextExtension);
                    foreach (string fullfile in files)
                    {
                        string file = Path.GetFileName(fullfile);
                        try
                        {
                            DateTime datetime = StringToDateTime(file);
                            array.Add(datetime);
                        }
                        catch
                        {
                            continue;
                        }
                    }
                }
                catch { }
            }

            DateTime[] dt = new DateTime[array.Count];
            for (int i = 0; i < array.Count; i++)
            {
                dt[i] = (DateTime)array[i];
            }

            calendar.BoldedDates = dt;
        }

        //�̹� �ִ� ī�������� ����
        public void EmphasisCategori()
        {
            string filename = calendar.SelectionStart.ToString("yyyyMMdd");
            bool[] emphasis = new bool[Setting.CateLimit];
            for (int i = 0; i < Setting.CateLimit; i++)
            {
                string path = String.Format("{0}\\{1}.{2}", Setting.CatePath[i], filename, Setting.TextExtension);
                emphasis[i] = File.Exists(path);
            }

            if (emphasis[0])
                btnCate0.Font = new Font(btnCate0.Font, FontStyle.Bold);
            else
                btnCate0.Font = new Font(btnCate0.Font, FontStyle.Regular);

            if (emphasis[1])
                btnCate1.Font = new Font(btnCate0.Font, FontStyle.Bold);
            else
                btnCate1.Font = new Font(btnCate0.Font, FontStyle.Regular);

            if (emphasis[2])
                btnCate2.Font = new Font(btnCate0.Font, FontStyle.Bold);
            else
                btnCate2.Font = new Font(btnCate0.Font, FontStyle.Regular);

            if (emphasis[3])
                btnCate3.Font = new Font(btnCate0.Font, FontStyle.Bold);
            else
                btnCate3.Font = new Font(btnCate0.Font, FontStyle.Regular);

            if (emphasis[4])
                btnCate4.Font = new Font(btnCate0.Font, FontStyle.Bold);
            else
                btnCate4.Font = new Font(btnCate0.Font, FontStyle.Regular);
        }

        //���ϸ����� Calendar ����
        public void RefreshCalendar()
        {
            int count = 0;
            foreach (string dirpath in Setting.CatePath)
            {
                if (Path.GetFullPath(dirpath) == Path.GetDirectoryName(filePath))
                {

                    string path = Path.GetFileName(filePath);

                    try
                    {
                        calendar.SelectionStart = StringToDateTime(path);
                        calendar.SelectionEnd = calendar.SelectionStart;

                        if (count == 0)
                            NowText = NowText.Categori0;
                        if (count == 1)
                            NowText = NowText.Categori1;
                        if (count == 2)
                            NowText = NowText.Categori2;
                        if (count == 3)
                            NowText = NowText.Categori3;
                        if (count == 4)
                            NowText = NowText.Categori4;

                    }
                    catch
                    {
                    }
                }
                count++;
            }

        }

        //��������� ���� ��Ĩ�ϴ�.
        public void RefreshAll()
        {
            //Setting �ҷ�����
            try
            {
                Setting = (Setting)XmlWritter.Load(Setting.SettingFilePath, new Setting());
            }
            catch
            {
                Setting = new Setting();
            }

            //Language �ҷ�����
            try
            {
                Language = (Language)XmlWritter.Load(Setting.LanguageFilePath, new Language());
            }
            catch
            {
                Language = new Language();
            }

            //Language ����
            this.Text = Language.Main_TitleName;

            this.btnCate0.Text = Setting.Main_Cate[0];
            this.btnCate1.Text = Setting.Main_Cate[1];
            this.btnCate2.Text = Setting.Main_Cate[2];
            this.btnCate3.Text = Setting.Main_Cate[3];
            this.btnCate4.Text = Setting.Main_Cate[4];

            this.btnSetting.Text = Language.Main_Setting;
            this.tsbAddFolder.Text = Language.Tree_AddFolder;
            this.tsbAddText.Text = Language.Tree_AddText;
            this.tsbRefresh.Text = Language.Tree_Refresh;
            this.tsbRemove.Text = Language.Tree_Remove;
            this.tsbRename.Text = Language.Tree_Rename;

            this.tsmi_Copy.Text = Language.Context_Copy;
            this.tsmi_Cut.Text = Language.Context_Cut;
            this.tsmi_Delete.Text = Language.Context_Delete;
            this.tsmi_LoadAgain.Text = Language.Context_LoadAgain;
            this.tsmi_Paste.Text = Language.Context_Paste;
            this.tsmi_SelectAll.Text = Language.Context_SelectAll;
            this.tsmi_Undo.Text = Language.Context_Undo;
            this.tsmi_Print.Text = Language.Context_Print;

            this.tsmiEdit.Text = Language.Tree_Rename;
            this.tsmiNewFolder.Text = Language.Tree_AddFolder;
            this.tsmiNewText.Text = Language.Tree_AddText;
            this.tsmiRefresh.Text = Language.Tree_Refresh;
            this.tsmiRemove.Text = Language.Tree_Remove;
            this.tsmiRun.Text = Language.Tree_Run;
            this.toolTip.SetToolTip(this.btnRemoveCurrentFile, Language.Main_RemoveCurrentFile);

            //Setting����
            //Ʈ���丸 ��� - �޷� ����
            if (Setting.UseTreeViewOnly)
            {
                calendar.Visible = false;
                Setting.UseableCate = 0;
                treeView.Size = new Size(treeView.Size.Width, treeView.Size.Height + treeView.Location.Y - calendar.Location.Y);
                treeView.Location = calendar.Location;
            }
            //ī�װ��� ����
            if (Setting.UseableCate < 1)
                btnCate0.Visible = false;
            if (Setting.UseableCate < 2)
                btnCate1.Visible = false;
            if (Setting.UseableCate < 3)
                btnCate2.Visible = false;
            if (Setting.UseableCate < 4)
                btnCate3.Visible = false;
            if (Setting.UseableCate < 5)
                btnCate4.Visible = false;
            //Splitter ����
            splitContainer.SplitterDistance = Setting.SplitterDistance;
            splitContainer.Panel1MinSize = Setting.MinSplitterDistance;
            if (Setting.AutoSplitterDistance)
            {
                splitContainer.SplitterDistance
                    = splitContainer.Panel1MinSize
                    = calendar.Size.Width + calendar.Location.X + 9;
            }
            //���� ��ġ
            if (Setting.UseCurrentPath)
            {
                Setting.TreeViewPath = Environment.CurrentDirectory;
            }
            //AutoSave
            timAutoSave.Enabled = Setting.AutoSave;
            //Recycle Bin
            if (Setting.UseRecycleBin)
                RecycleOption = RecycleOption.SendToRecycleBin;
            else
                RecycleOption = RecycleOption.DeletePermanently;

            //��Ʈ ũ��
            rtbText.Font = new Font(Font.FontFamily, Setting.FontSize);
            btnCate0.Font = new Font(Font.FontFamily, Setting.ButtonFontSize);
            btnCate1.Font = new Font(Font.FontFamily, Setting.ButtonFontSize);
            btnCate2.Font = new Font(Font.FontFamily, Setting.ButtonFontSize);
            btnCate3.Font = new Font(Font.FontFamily, Setting.ButtonFontSize);
            btnCate4.Font = new Font(Font.FontFamily, Setting.ButtonFontSize);
            btnSetting.Font = new Font(Font.FontFamily, Setting.ButtonFontSize);


            //calender �����ִ� ��¥ ����
            RefreshBoiledDates();

            //�ּ����� TreeView�����ֱ�
            //TreeNode treeNode = new TreeNode(Setting.TreeViewPath, 0, 1);
            //treeView.Nodes.Add(treeNode);

            //��ü ������Ʈ
            RefreshTree();

            //TreeView����
            treeView.Select();
        }

        //���� ���ϸ� ã��
        public string GetFullPath(string Path)
        {
            //������ �����Ұ�� �׳� ��ȯ
            if (File.Exists(Path))
            {
                return Path;
            }
            //�����ϴ� Ȯ������ ���ϸ� ã��
            else
            {
                if (System.IO.Path.GetFileName(Path).ToLower() == Setting.FolderCommentFile.ToLower())
                    return Path;
                foreach (string ex in Setting.Extensions)
                {
                    string ex2 = System.IO.Path.GetExtension(ex);
                    if (File.Exists(Path + ex2))
                    {
                        return Path + ex2;
                    }
                }
            }
            //���� ������ �ùٸ� Ȯ���ڸ� ������ ������� �׳� ��ȯ
            foreach (string ex in Setting.Extensions)
            {
                if (System.IO.Path.GetExtension(Path) == System.IO.Path.GetExtension(ex))
                    return Path;
            }
            return Path + "." + Setting.TextExtension;

        }






    }


}
