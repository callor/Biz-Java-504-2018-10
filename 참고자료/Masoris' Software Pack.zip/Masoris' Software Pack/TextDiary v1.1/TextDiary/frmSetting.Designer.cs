﻿namespace TextDiary
{
    partial class frmSetting
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Cancle = new System.Windows.Forms.Button();
            this.btn_OpenSetting = new System.Windows.Forms.Button();
            this.btn_OpenLanguage = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMadeby = new System.Windows.Forms.Label();
            this.lblWhenRestart = new System.Windows.Forms.Label();
            this.gBoxCategori = new System.Windows.Forms.GroupBox();
            this.lblCategoriPath = new System.Windows.Forms.Label();
            this.lblCategoriName = new System.Windows.Forms.Label();
            this.lblNumberOfCategori = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.nudNumberOfCategori = new System.Windows.Forms.NumericUpDown();
            this.btn_OK = new System.Windows.Forms.Button();
            this.ckboxUseTreeViewOnly = new System.Windows.Forms.CheckBox();
            this.ckboxAutoSave = new System.Windows.Forms.CheckBox();
            this.gBoxCategori.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumberOfCategori)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Cancle
            // 
            this.btn_Cancle.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancle.Location = new System.Drawing.Point(251, 378);
            this.btn_Cancle.Name = "btn_Cancle";
            this.btn_Cancle.Size = new System.Drawing.Size(73, 27);
            this.btn_Cancle.TabIndex = 3;
            this.btn_Cancle.Text = "button1";
            this.btn_Cancle.UseVisualStyleBackColor = true;
            this.btn_Cancle.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // btn_OpenSetting
            // 
            this.btn_OpenSetting.Location = new System.Drawing.Point(14, 378);
            this.btn_OpenSetting.Name = "btn_OpenSetting";
            this.btn_OpenSetting.Size = new System.Drawing.Size(73, 27);
            this.btn_OpenSetting.TabIndex = 0;
            this.btn_OpenSetting.Text = "button1";
            this.btn_OpenSetting.UseVisualStyleBackColor = true;
            this.btn_OpenSetting.Click += new System.EventHandler(this.btn_OpenSetting_Click);
            // 
            // btn_OpenLanguage
            // 
            this.btn_OpenLanguage.Location = new System.Drawing.Point(93, 378);
            this.btn_OpenLanguage.Name = "btn_OpenLanguage";
            this.btn_OpenLanguage.Size = new System.Drawing.Size(73, 27);
            this.btn_OpenLanguage.TabIndex = 1;
            this.btn_OpenLanguage.Text = "button1";
            this.btn_OpenLanguage.UseVisualStyleBackColor = true;
            this.btn_OpenLanguage.Click += new System.EventHandler(this.btn_OpenLanguage_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림체", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 64);
            this.label1.TabIndex = 1;
            this.label1.Text = "-ㅅ-)/";
            // 
            // lblMadeby
            // 
            this.lblMadeby.AutoSize = true;
            this.lblMadeby.Location = new System.Drawing.Point(20, 73);
            this.lblMadeby.Name = "lblMadeby";
            this.lblMadeby.Size = new System.Drawing.Size(35, 13);
            this.lblMadeby.TabIndex = 2;
            this.lblMadeby.Text = "label2";
            // 
            // lblWhenRestart
            // 
            this.lblWhenRestart.AutoSize = true;
            this.lblWhenRestart.Location = new System.Drawing.Point(18, 352);
            this.lblWhenRestart.Name = "lblWhenRestart";
            this.lblWhenRestart.Size = new System.Drawing.Size(35, 13);
            this.lblWhenRestart.TabIndex = 3;
            this.lblWhenRestart.Text = "label2";
            // 
            // gBoxCategori
            // 
            this.gBoxCategori.Controls.Add(this.lblCategoriPath);
            this.gBoxCategori.Controls.Add(this.lblCategoriName);
            this.gBoxCategori.Controls.Add(this.lblNumberOfCategori);
            this.gBoxCategori.Controls.Add(this.textBox10);
            this.gBoxCategori.Controls.Add(this.textBox8);
            this.gBoxCategori.Controls.Add(this.textBox6);
            this.gBoxCategori.Controls.Add(this.textBox4);
            this.gBoxCategori.Controls.Add(this.textBox2);
            this.gBoxCategori.Controls.Add(this.textBox9);
            this.gBoxCategori.Controls.Add(this.textBox7);
            this.gBoxCategori.Controls.Add(this.textBox5);
            this.gBoxCategori.Controls.Add(this.textBox3);
            this.gBoxCategori.Controls.Add(this.textBox1);
            this.gBoxCategori.Controls.Add(this.nudNumberOfCategori);
            this.gBoxCategori.Location = new System.Drawing.Point(12, 89);
            this.gBoxCategori.Name = "gBoxCategori";
            this.gBoxCategori.Size = new System.Drawing.Size(312, 214);
            this.gBoxCategori.TabIndex = 4;
            this.gBoxCategori.TabStop = false;
            this.gBoxCategori.Text = "groupBox1";
            // 
            // lblCategoriPath
            // 
            this.lblCategoriPath.AutoSize = true;
            this.lblCategoriPath.Location = new System.Drawing.Point(133, 62);
            this.lblCategoriPath.Name = "lblCategoriPath";
            this.lblCategoriPath.Size = new System.Drawing.Size(35, 13);
            this.lblCategoriPath.TabIndex = 3;
            this.lblCategoriPath.Text = "label2";
            // 
            // lblCategoriName
            // 
            this.lblCategoriName.AutoSize = true;
            this.lblCategoriName.Location = new System.Drawing.Point(6, 62);
            this.lblCategoriName.Name = "lblCategoriName";
            this.lblCategoriName.Size = new System.Drawing.Size(35, 13);
            this.lblCategoriName.TabIndex = 3;
            this.lblCategoriName.Text = "label2";
            // 
            // lblNumberOfCategori
            // 
            this.lblNumberOfCategori.AutoSize = true;
            this.lblNumberOfCategori.Location = new System.Drawing.Point(6, 23);
            this.lblNumberOfCategori.Name = "lblNumberOfCategori";
            this.lblNumberOfCategori.Size = new System.Drawing.Size(35, 13);
            this.lblNumberOfCategori.TabIndex = 3;
            this.lblNumberOfCategori.Text = "label2";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(136, 182);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(170, 20);
            this.textBox10.TabIndex = 10;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(136, 156);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(170, 20);
            this.textBox8.TabIndex = 8;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(136, 130);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(170, 20);
            this.textBox6.TabIndex = 6;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(136, 104);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(170, 20);
            this.textBox4.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(136, 78);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(170, 20);
            this.textBox2.TabIndex = 2;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(6, 182);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(124, 20);
            this.textBox9.TabIndex = 9;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(6, 156);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(124, 20);
            this.textBox7.TabIndex = 7;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(6, 130);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(124, 20);
            this.textBox5.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(6, 104);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(124, 20);
            this.textBox3.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 78);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(124, 20);
            this.textBox1.TabIndex = 1;
            // 
            // nudNumberOfCategori
            // 
            this.nudNumberOfCategori.Location = new System.Drawing.Point(6, 39);
            this.nudNumberOfCategori.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudNumberOfCategori.Name = "nudNumberOfCategori";
            this.nudNumberOfCategori.Size = new System.Drawing.Size(37, 20);
            this.nudNumberOfCategori.TabIndex = 0;
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(172, 378);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(73, 27);
            this.btn_OK.TabIndex = 2;
            this.btn_OK.Text = "button1";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // ckboxUseTreeViewOnly
            // 
            this.ckboxUseTreeViewOnly.AutoSize = true;
            this.ckboxUseTreeViewOnly.Location = new System.Drawing.Point(18, 309);
            this.ckboxUseTreeViewOnly.Name = "ckboxUseTreeViewOnly";
            this.ckboxUseTreeViewOnly.Size = new System.Drawing.Size(80, 17);
            this.ckboxUseTreeViewOnly.TabIndex = 5;
            this.ckboxUseTreeViewOnly.Text = "checkBox1";
            this.ckboxUseTreeViewOnly.UseVisualStyleBackColor = true;
            // 
            // ckboxAutoSave
            // 
            this.ckboxAutoSave.AutoSize = true;
            this.ckboxAutoSave.Location = new System.Drawing.Point(18, 332);
            this.ckboxAutoSave.Name = "ckboxAutoSave";
            this.ckboxAutoSave.Size = new System.Drawing.Size(80, 17);
            this.ckboxAutoSave.TabIndex = 6;
            this.ckboxAutoSave.Text = "checkBox1";
            this.ckboxAutoSave.UseVisualStyleBackColor = true;
            // 
            // frmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 417);
            this.Controls.Add(this.ckboxAutoSave);
            this.Controls.Add(this.ckboxUseTreeViewOnly);
            this.Controls.Add(this.gBoxCategori);
            this.Controls.Add(this.lblWhenRestart);
            this.Controls.Add(this.lblMadeby);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.btn_OpenLanguage);
            this.Controls.Add(this.btn_OpenSetting);
            this.Controls.Add(this.btn_Cancle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "frmSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmSetting";
            this.Load += new System.EventHandler(this.frmSetting_Load);
            this.gBoxCategori.ResumeLayout(false);
            this.gBoxCategori.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumberOfCategori)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Cancle;
        private System.Windows.Forms.Button btn_OpenSetting;
        private System.Windows.Forms.Button btn_OpenLanguage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMadeby;
        private System.Windows.Forms.Label lblWhenRestart;
        private System.Windows.Forms.GroupBox gBoxCategori;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.NumericUpDown nudNumberOfCategori;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Label lblCategoriPath;
        private System.Windows.Forms.Label lblCategoriName;
        private System.Windows.Forms.Label lblNumberOfCategori;
        private System.Windows.Forms.CheckBox ckboxUseTreeViewOnly;
        private System.Windows.Forms.CheckBox ckboxAutoSave;

    }
}