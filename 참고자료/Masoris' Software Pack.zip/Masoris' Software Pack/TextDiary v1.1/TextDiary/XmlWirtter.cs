using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace TextDiary
{


    public static class XmlWritter
    {
        public static void Save(string Path, object Object)
        {
            XmlSerializer formatter = new XmlSerializer(Object.GetType());
            Stream stream = new FileStream(Path, FileMode.Create, FileAccess.Write, FileShare.Read);
            formatter.Serialize(stream, Object);
            stream.Close();
        }

        public static object Load(string Path, object Object)
        {
            XmlSerializer formatter = new XmlSerializer(Object.GetType());
            Stream stream = new FileStream(Path, FileMode.Open, FileAccess.Read, FileShare.Read);
            object result = formatter.Deserialize(stream);
            stream.Close();
            return result;
        }


    }
}
