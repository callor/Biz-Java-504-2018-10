using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace TextDiary
{
    public partial class frmSetting : Form
    {
        public frmMain frmMain;
        public frmSetting()
        {
            InitializeComponent();
        }

        private void frmSetting_Load(object sender, EventArgs e)
        {

            //Language �ҷ�����
            Text = frmMain.Language.Main_Setting;
            lblMadeby.Text = String.Format(frmMain.Language.Setting_MadeBy, Language.Creator, Setting.ProgramVersion);
            btn_Cancle.Text = frmMain.Language.Button_Cancel;
            btn_OK.Text = frmMain.Language.Button_OK;
            btn_OpenLanguage.Text = frmMain.Language.Setting_EditLangauge;
            btn_OpenSetting.Text = frmMain.Language.Setting_EditSetting;
            lblWhenRestart.Text = frmMain.Language.ApplyWhenRestart;
            lblCategoriName.Text = frmMain.Language.Setting_CategoriName;
            lblCategoriPath.Text = frmMain.Language.Setting_CategoriPath;
            lblNumberOfCategori.Text = frmMain.Language.Setting_NumberOfCategori;
            gBoxCategori.Text = frmMain.Language.Setting_Categori;
            ckboxUseTreeViewOnly.Text = frmMain.Language.Setting_UseTreeViewOnly;
            ckboxAutoSave.Text = frmMain.Language.Setting_AutoSave;

            //Setting �ҷ�����
            nudNumberOfCategori.Value = frmMain.Setting.UseableCate;
            textBox1.Text = frmMain.Setting.Main_Cate[0];
            textBox3.Text = frmMain.Setting.Main_Cate[1];
            textBox5.Text = frmMain.Setting.Main_Cate[2];
            textBox7.Text = frmMain.Setting.Main_Cate[3];
            textBox9.Text = frmMain.Setting.Main_Cate[4];
            textBox2.Text = frmMain.Setting.CatePath[0];
            textBox4.Text = frmMain.Setting.CatePath[1];
            textBox6.Text = frmMain.Setting.CatePath[2];
            textBox8.Text = frmMain.Setting.CatePath[3];
            textBox10.Text = frmMain.Setting.CatePath[4];
            ckboxUseTreeViewOnly.Checked = frmMain.Setting.UseTreeViewOnly;
            ckboxAutoSave.Checked = frmMain.Setting.AutoSave;
            

            //��Ʈũ�� ����
            btn_Cancle.Font = new Font(Font.FontFamily, frmMain.Setting.ButtonFontSize);
            btn_OK.Font = new Font(Font.FontFamily, frmMain.Setting.ButtonFontSize);
            btn_OpenLanguage.Font = new Font(Font.FontFamily, frmMain.Setting.ButtonFontSize);
            btn_OpenSetting.Font = new Font(Font.FontFamily, frmMain.Setting.ButtonFontSize);
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_OpenSetting_Click(object sender, EventArgs e)
        {
            try
            {
            Setting setting = (Setting)XmlWritter.Load(Setting.SettingFilePath, frmMain.Setting);
            XmlWritter.Save(Setting.SettingFilePath, setting);
            }
            catch
            {
                XmlWritter.Save(Setting.SettingFilePath, frmMain.Setting);
            }

            frmMain.NowText = NowText.File;
            frmMain.LoadTextFile(Setting.SettingFilePath, System.Text.Encoding.UTF8);
            Close();
        }

        private void btn_OpenLanguage_Click(object sender, EventArgs e)
        {
            try
            {
                Setting language = (Setting)XmlWritter.Load(frmMain.Setting.LanguageFilePath, frmMain.Language);
                XmlWritter.Save(frmMain.Setting.LanguageFilePath, language);
            }
            catch
            {
                XmlWritter.Save(frmMain.Setting.LanguageFilePath, frmMain.Language);
            }

            frmMain.NowText = NowText.File;
            frmMain.LoadTextFile(frmMain.Setting.LanguageFilePath, System.Text.Encoding.UTF8);
            Close();
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            frmMain.Setting.UseableCate = Convert.ToInt32(nudNumberOfCategori.Value);
            frmMain.Setting.Main_Cate[0] = textBox1.Text;
             frmMain.Setting.Main_Cate[1] = textBox3.Text;
             frmMain.Setting.Main_Cate[2] = textBox5.Text;
             frmMain.Setting.Main_Cate[3] = textBox7.Text;
             frmMain.Setting.Main_Cate[4] = textBox9.Text;
             frmMain.Setting.CatePath[0] = textBox2.Text;
             frmMain.Setting.CatePath[1] = textBox4.Text;
            frmMain.Setting.CatePath[2] = textBox6.Text;
           frmMain.Setting.CatePath[3] =  textBox8.Text;
            frmMain.Setting.CatePath[4] = textBox10.Text;
            frmMain.Setting.UseTreeViewOnly = ckboxUseTreeViewOnly.Checked;
            frmMain.Setting.AutoSave = ckboxAutoSave.Checked;

            XmlWritter.Save(Setting.SettingFilePath, frmMain.Setting);
            Close();
        }
    }
}