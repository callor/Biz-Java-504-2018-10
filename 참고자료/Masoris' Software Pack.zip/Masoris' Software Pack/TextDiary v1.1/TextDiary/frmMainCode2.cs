using System;
using System.Collections.Generic;
using System.Text;

namespace TextDiary
{
    public partial class frmMain
    {
        public DateTime StringToDateTime(string str)
        {
            int year = Convert.ToInt32(str.Substring(0, 4));
            int month = Convert.ToInt32(str.Substring(4, 2));
            int day = Convert.ToInt32(str.Substring(6, 2));
            DateTime datetime = new DateTime(year, month, day);
            return datetime;
            
        }
    }
}
