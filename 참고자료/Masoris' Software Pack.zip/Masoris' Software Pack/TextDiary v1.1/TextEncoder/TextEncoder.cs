using System;
using System.Collections.Generic;
using System.Text;

namespace TextEncoder
{
    public static class TextEncoder
    {
        public static void StringToFile(string Path, string String)
        {
        }
        public static void StringToFile(string Path, string[] Lines)
        {
        }
        public static void StringToFile(string Path, string String, Encoding Encoding)
        {
        }
        public static void StringToFile(string Path, string[] Lines, Encoding Encoding)
        {
        }

        public static string FileToString(string Path)
        {
            return null;
        }
        public static string FileToString(string Path, Encoding DefaultEncoding)
        {
            return null;
        }

        public static Encoding GetFileEncoding(string Path)
        {
            return null;
        }
    }
}
