using System;
using System.Collections.Generic;
using System.Text;

namespace TextEncoder
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
