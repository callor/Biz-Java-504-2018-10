Public Class frmFind
    Inherits System.Windows.Forms.Form

#Region " Windows Form 디자이너에서 생성한 코드 "

    Public Sub New()
        MyBase.New()

        '이 호출은 Windows Form 디자이너에 필요합니다.
        InitializeComponent()

        'InitializeComponent()를 호출한 다음에 초기화 작업을 추가하십시오.

    End Sub

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    'Windows Form 디자이너를 사용하여 수정할 수 있습니다.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Kion : "
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(64, 16)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(152, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = ""
        '
        'CheckBox1
        '
        Me.CheckBox1.Location = New System.Drawing.Point(8, 56)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(104, 32)
        Me.CheckBox1.TabIndex = 2
        Me.CheckBox1.Text = "Ŝaku Majusko kaj Minusklo"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Location = New System.Drawing.Point(104, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(112, 48)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Al kie"
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(8, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(48, 16)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Sure"
        '
        'RadioButton2
        '
        Me.RadioButton2.Checked = True
        Me.RadioButton2.Location = New System.Drawing.Point(48, 24)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(56, 16)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Sube"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(224, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(72, 24)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Serĉu Plu"
        '
        'Button2
        '
        Me.Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button2.Location = New System.Drawing.Point(224, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(72, 24)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Nuliĝu"
        '
        'frmFind
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.Button2
        Me.ClientSize = New System.Drawing.Size(314, 104)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmFind"
        Me.Text = "Serĉu"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public frmM As frmMain

    Public Function Find() As Boolean
        Dim intTemp As Integer = frmM.rtxtMain.SelectionStart()
        Call Button1_Click(Nothing, Nothing)
        If intTemp = frmM.rtxtMain.SelectionStart() Then
            Return True
        Else
            Return False
        End If
    End Function
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (TextBox1.Text.Length = 0) Then Exit Sub
        frmM.strFindWhat = TextBox1.Text
        frmM.bFindUp = RadioButton1.Checked
        frmM.bCase = Me.CheckBox1.Checked
        Try


            frmM.Focus()
            Dim Count As Integer
            Count = frmM.rtxtMain.SelectionStart
            If Me.RadioButton1.Checked = True Then
                For Count = Count - 1 To 0 Step -1
                    If (CheckBox1.Checked = True) Then
                        If (frmM.rtxtMain.Text.Substring(Count, TextBox1.Text.Length).ToLower = TextBox1.Text.ToLower) Then
                            frmM.rtxtMain.SelectionStart = Count
                            frmM.rtxtMain.SelectionLength = TextBox1.Text.Length
                            Exit Sub
                        End If
                    Else
                        If (frmM.rtxtMain.Text.Substring(Count, TextBox1.Text.Length) = TextBox1.Text) Then
                            frmM.rtxtMain.SelectionStart = Count
                            frmM.rtxtMain.SelectionLength = TextBox1.Text.Length
                            Exit Sub
                        End If
                    End If
                Next
            Else

                For Count = Count + 1 To frmM.rtxtMain.Text.Length - TextBox1.Text.Length
                    If (CheckBox1.Checked = True) Then
                        If (frmM.rtxtMain.Text.Substring(Count, TextBox1.Text.Length).ToLower = TextBox1.Text.ToLower) Then
                            frmM.rtxtMain.SelectionStart = Count
                            frmM.rtxtMain.SelectionLength = TextBox1.Text.Length
                            Exit Sub
                        End If
                    Else
                        If (frmM.rtxtMain.Text.Substring(Count, TextBox1.Text.Length) = TextBox1.Text) Then
                            frmM.rtxtMain.SelectionStart = Count
                            frmM.rtxtMain.SelectionLength = TextBox1.Text.Length
                            Exit Sub
                        End If
                    End If
                Next
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
