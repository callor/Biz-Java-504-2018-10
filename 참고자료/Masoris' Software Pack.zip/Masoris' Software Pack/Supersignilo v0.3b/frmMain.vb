Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form 디자이너에서 생성한 코드 "

    Public Sub New()
        MyBase.New()

        '이 호출은 Windows Form 디자이너에 필요합니다.
        InitializeComponent()

        'InitializeComponent()를 호출한 다음에 초기화 작업을 추가하십시오.

    End Sub

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    'Windows Form 디자이너를 사용하여 수정할 수 있습니다.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem18 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem19 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem20 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem21 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem22 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem23 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem24 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem25 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem26 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem27 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem28 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem29 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem30 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem31 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem32 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem33 As System.Windows.Forms.MenuItem
    Friend WithEvents rtxtMain As System.Windows.Forms.RichTextBox
    Friend WithEvents MenuItem34 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem35 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem36 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem37 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem39 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem40 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem41 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem42 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PageSetupDialog1 As System.Windows.Forms.PageSetupDialog
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents MenuItem38 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem43 As System.Windows.Forms.MenuItem
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem44 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem45 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem46 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem47 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem48 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem49 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem50 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem51 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem52 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem52 = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.MenuItem13 = New System.Windows.Forms.MenuItem
        Me.MenuItem15 = New System.Windows.Forms.MenuItem
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        Me.MenuItem19 = New System.Windows.Forms.MenuItem
        Me.MenuItem18 = New System.Windows.Forms.MenuItem
        Me.MenuItem20 = New System.Windows.Forms.MenuItem
        Me.MenuItem21 = New System.Windows.Forms.MenuItem
        Me.MenuItem22 = New System.Windows.Forms.MenuItem
        Me.MenuItem24 = New System.Windows.Forms.MenuItem
        Me.MenuItem23 = New System.Windows.Forms.MenuItem
        Me.MenuItem25 = New System.Windows.Forms.MenuItem
        Me.MenuItem26 = New System.Windows.Forms.MenuItem
        Me.MenuItem34 = New System.Windows.Forms.MenuItem
        Me.MenuItem35 = New System.Windows.Forms.MenuItem
        Me.MenuItem36 = New System.Windows.Forms.MenuItem
        Me.MenuItem37 = New System.Windows.Forms.MenuItem
        Me.MenuItem40 = New System.Windows.Forms.MenuItem
        Me.MenuItem39 = New System.Windows.Forms.MenuItem
        Me.MenuItem42 = New System.Windows.Forms.MenuItem
        Me.MenuItem41 = New System.Windows.Forms.MenuItem
        Me.MenuItem38 = New System.Windows.Forms.MenuItem
        Me.MenuItem43 = New System.Windows.Forms.MenuItem
        Me.MenuItem27 = New System.Windows.Forms.MenuItem
        Me.MenuItem28 = New System.Windows.Forms.MenuItem
        Me.MenuItem29 = New System.Windows.Forms.MenuItem
        Me.MenuItem31 = New System.Windows.Forms.MenuItem
        Me.MenuItem30 = New System.Windows.Forms.MenuItem
        Me.MenuItem32 = New System.Windows.Forms.MenuItem
        Me.MenuItem33 = New System.Windows.Forms.MenuItem
        Me.rtxtMain = New System.Windows.Forms.RichTextBox
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu
        Me.MenuItem44 = New System.Windows.Forms.MenuItem
        Me.MenuItem46 = New System.Windows.Forms.MenuItem
        Me.MenuItem45 = New System.Windows.Forms.MenuItem
        Me.MenuItem47 = New System.Windows.Forms.MenuItem
        Me.MenuItem48 = New System.Windows.Forms.MenuItem
        Me.MenuItem49 = New System.Windows.Forms.MenuItem
        Me.MenuItem51 = New System.Windows.Forms.MenuItem
        Me.MenuItem50 = New System.Windows.Forms.MenuItem
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument
        Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog
        Me.FontDialog1 = New System.Windows.Forms.FontDialog
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem11, Me.MenuItem26, Me.MenuItem27, Me.MenuItem32})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8, Me.MenuItem10, Me.MenuItem9})
        Me.MenuItem1.Text = "Dosiero"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Shortcut = System.Windows.Forms.Shortcut.CtrlN
        Me.MenuItem2.Text = "Nova Dosiero"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.MenuItem3.Text = "Malfermu..."
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        Me.MenuItem4.Text = "Savu"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.Text = "Savu per..."
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.Text = "-"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 5
        Me.MenuItem7.Text = "Paĝon Agrodu..."
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 6
        Me.MenuItem8.Shortcut = System.Windows.Forms.Shortcut.CtrlP
        Me.MenuItem8.Text = "Printu..."
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 7
        Me.MenuItem10.Text = "-"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 8
        Me.MenuItem9.Text = "Eliru"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 1
        Me.MenuItem11.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem12, Me.MenuItem52, Me.MenuItem14, Me.MenuItem13, Me.MenuItem15, Me.MenuItem16, Me.MenuItem17, Me.MenuItem19, Me.MenuItem18, Me.MenuItem20, Me.MenuItem21, Me.MenuItem22, Me.MenuItem24, Me.MenuItem23, Me.MenuItem25})
        Me.MenuItem11.Text = "Radakto"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 0
        Me.MenuItem12.Shortcut = System.Windows.Forms.Shortcut.CtrlZ
        Me.MenuItem12.Text = "Malfaru"
        '
        'MenuItem52
        '
        Me.MenuItem52.Index = 1
        Me.MenuItem52.Text = "Malfaru Ĉion"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 2
        Me.MenuItem14.Text = "-"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 3
        Me.MenuItem13.Shortcut = System.Windows.Forms.Shortcut.CtrlX
        Me.MenuItem13.Text = "Tondut"
        '
        'MenuItem15
        '
        Me.MenuItem15.Index = 4
        Me.MenuItem15.Shortcut = System.Windows.Forms.Shortcut.CtrlC
        Me.MenuItem15.Text = "Kopiu"
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 5
        Me.MenuItem16.Shortcut = System.Windows.Forms.Shortcut.CtrlV
        Me.MenuItem16.Text = "Algluu"
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 6
        Me.MenuItem17.Shortcut = System.Windows.Forms.Shortcut.Del
        Me.MenuItem17.Text = "Forĵetu"
        '
        'MenuItem19
        '
        Me.MenuItem19.Index = 7
        Me.MenuItem19.Text = "-"
        '
        'MenuItem18
        '
        Me.MenuItem18.Index = 8
        Me.MenuItem18.Shortcut = System.Windows.Forms.Shortcut.CtrlF
        Me.MenuItem18.Text = "Serĉu..."
        '
        'MenuItem20
        '
        Me.MenuItem20.Index = 9
        Me.MenuItem20.Shortcut = System.Windows.Forms.Shortcut.F3
        Me.MenuItem20.Text = "Serĉu plu"
        '
        'MenuItem21
        '
        Me.MenuItem21.Index = 10
        Me.MenuItem21.Shortcut = System.Windows.Forms.Shortcut.CtrlH
        Me.MenuItem21.Text = "Sanĝu..."
        '
        'MenuItem22
        '
        Me.MenuItem22.Index = 11
        Me.MenuItem22.Shortcut = System.Windows.Forms.Shortcut.CtrlG
        Me.MenuItem22.Text = "Movu..."
        '
        'MenuItem24
        '
        Me.MenuItem24.Index = 12
        Me.MenuItem24.Text = "-"
        '
        'MenuItem23
        '
        Me.MenuItem23.Index = 13
        Me.MenuItem23.Shortcut = System.Windows.Forms.Shortcut.CtrlA
        Me.MenuItem23.Text = "Seletu Ĉiun"
        '
        'MenuItem25
        '
        Me.MenuItem25.Index = 14
        Me.MenuItem25.Shortcut = System.Windows.Forms.Shortcut.F5
        Me.MenuItem25.Text = "Tempo/Tago"
        '
        'MenuItem26
        '
        Me.MenuItem26.Index = 2
        Me.MenuItem26.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem34, Me.MenuItem35, Me.MenuItem36, Me.MenuItem37, Me.MenuItem40, Me.MenuItem39, Me.MenuItem42, Me.MenuItem41, Me.MenuItem38, Me.MenuItem43})
        Me.MenuItem26.Text = "Supersigno"
        '
        'MenuItem34
        '
        Me.MenuItem34.Index = 0
        Me.MenuItem34.Shortcut = System.Windows.Forms.Shortcut.Ctrl1
        Me.MenuItem34.Text = "Detala..."
        '
        'MenuItem35
        '
        Me.MenuItem35.Checked = True
        Me.MenuItem35.Index = 1
        Me.MenuItem35.Shortcut = System.Windows.Forms.Shortcut.Ctrl2
        Me.MenuItem35.Text = "Defaŭlto"
        '
        'MenuItem36
        '
        Me.MenuItem36.Index = 2
        Me.MenuItem36.Shortcut = System.Windows.Forms.Shortcut.Ctrl3
        Me.MenuItem36.Text = "xSistemo"
        '
        'MenuItem37
        '
        Me.MenuItem37.Index = 3
        Me.MenuItem37.Shortcut = System.Windows.Forms.Shortcut.Ctrl4
        Me.MenuItem37.Text = "hSistemo"
        '
        'MenuItem40
        '
        Me.MenuItem40.Index = 4
        Me.MenuItem40.Shortcut = System.Windows.Forms.Shortcut.Ctrl5
        Me.MenuItem40.Text = "Ne Uzu"
        '
        'MenuItem39
        '
        Me.MenuItem39.Index = 5
        Me.MenuItem39.Text = "-"
        '
        'MenuItem42
        '
        Me.MenuItem42.Index = 6
        Me.MenuItem42.Shortcut = System.Windows.Forms.Shortcut.Ctrl6
        Me.MenuItem42.Text = "Supersigniĝu"
        '
        'MenuItem41
        '
        Me.MenuItem41.Index = 7
        Me.MenuItem41.Shortcut = System.Windows.Forms.Shortcut.Ctrl7
        Me.MenuItem41.Text = "Malsupersigniĝu..."
        '
        'MenuItem38
        '
        Me.MenuItem38.Index = 8
        Me.MenuItem38.Text = "-"
        '
        'MenuItem43
        '
        Me.MenuItem43.Index = 9
        Me.MenuItem43.Text = "Savu Agordon"
        '
        'MenuItem27
        '
        Me.MenuItem27.Index = 3
        Me.MenuItem27.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem28, Me.MenuItem29, Me.MenuItem31, Me.MenuItem30})
        Me.MenuItem27.Text = "Vido"
        '
        'MenuItem28
        '
        Me.MenuItem28.Checked = True
        Me.MenuItem28.Index = 0
        Me.MenuItem28.Text = "Linifaldo"
        '
        'MenuItem29
        '
        Me.MenuItem29.Index = 1
        Me.MenuItem29.Text = "Tiparo..."
        '
        'MenuItem31
        '
        Me.MenuItem31.Index = 2
        Me.MenuItem31.Text = "-"
        '
        'MenuItem30
        '
        Me.MenuItem30.Index = 3
        Me.MenuItem30.Text = "Subbaro"
        '
        'MenuItem32
        '
        Me.MenuItem32.Index = 4
        Me.MenuItem32.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem33})
        Me.MenuItem32.Text = "Helpo"
        '
        'MenuItem33
        '
        Me.MenuItem33.Index = 0
        Me.MenuItem33.Text = "Pri Supersignilo..."
        '
        'rtxtMain
        '
        Me.rtxtMain.ContextMenu = Me.ContextMenu1
        Me.rtxtMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtxtMain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtxtMain.HideSelection = False
        Me.rtxtMain.Location = New System.Drawing.Point(0, 0)
        Me.rtxtMain.Name = "rtxtMain"
        Me.rtxtMain.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.rtxtMain.Size = New System.Drawing.Size(424, 253)
        Me.rtxtMain.TabIndex = 0
        Me.rtxtMain.Text = ""
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem44, Me.MenuItem46, Me.MenuItem45, Me.MenuItem47, Me.MenuItem48, Me.MenuItem49, Me.MenuItem51, Me.MenuItem50})
        '
        'MenuItem44
        '
        Me.MenuItem44.Index = 0
        Me.MenuItem44.Text = "Malfaru"
        '
        'MenuItem46
        '
        Me.MenuItem46.Index = 1
        Me.MenuItem46.Text = "-"
        '
        'MenuItem45
        '
        Me.MenuItem45.Index = 2
        Me.MenuItem45.Text = "Tondu"
        '
        'MenuItem47
        '
        Me.MenuItem47.Index = 3
        Me.MenuItem47.Text = "Kopiu"
        '
        'MenuItem48
        '
        Me.MenuItem48.Index = 4
        Me.MenuItem48.Text = "Alguu"
        '
        'MenuItem49
        '
        Me.MenuItem49.Index = 5
        Me.MenuItem49.Text = "Forĵetu"
        '
        'MenuItem51
        '
        Me.MenuItem51.Index = 6
        Me.MenuItem51.Text = "-"
        '
        'MenuItem50
        '
        Me.MenuItem50.Index = 7
        Me.MenuItem50.Text = "Selektu Ĉiu"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "Tekstaj Dosieroj (*.txt)|*.txt|RTF Formeto (*.rtf)|*.rtf|Ĉiuj Dosieroj (*.*)|*.*"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "Tekstaj Dosieroj (*.txt)|*.txt|RTF Formeto (*.rtf)|*.rtf|Ĉiuj Dosieroj (*.*)|*.*"
        '
        'PrintDocument1
        '
        '
        'PageSetupDialog1
        '
        Me.PageSetupDialog1.Document = Me.PrintDocument1
        '
        'PrintDialog1
        '
        Me.PrintDialog1.Document = Me.PrintDocument1
        '
        'FontDialog1
        '
        Me.FontDialog1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 237)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(424, 16)
        Me.StatusBar1.TabIndex = 1
        Me.StatusBar1.Visible = False
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 253)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.rtxtMain)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.MainMenu1
        Me.Name = "frmMain"
        Me.Text = "Supersignilo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    'For Input Supersigno
    'Setting Supersigno
    Private strSupersigno() As String = {"ĉ", "ĝ", "ĥ", "ĵ", "ŝ", "ŭ"}
    Private strOriginal() As String = {"c", "g", "h", "j", "s", "u"}
    Public strPrefix() As String = {"^", "'", ";", "/"}
    Public strSuffix() As String = {"x", "h", "^", "'"}
    Public strExcep() As String = {"w", "u~", "~u", ""}
    Public strExcepTo() As String = {"ŭ", "ŭ", "ŭ", ""}
    'Setting DirectKeyborad
    Public cDirect() As String = {"", "", "", "", "", ""}
    Public cDirectExcep As String = ""
    Public bDirect As Boolean = False
    Public intSelectedMenu As Integer = 1

    'Other Declarations
    Private strTyping As String = "   " 'Last Typed Chars
    Private Changed As String 'Last Changed Letter
    Private bIsUpper As Boolean 'Upper Supersigno or Not
    Public bRecoverable As Boolean = True
    Private cExcep As Char = Nothing 'Word for reChange

    'About NotePad
    Private strSoftname As String = "Supersignilo"
    Private strFileName As String = "Nova Dosiero"
    Private strFilePath As String = ""
    Private strMalfaru As String = ""
    Public strFindWhat As String
    Public bFindUp As Boolean
    Public bCase As Boolean
    Public intGoto As Integer = 1




#Region " Input Supersigno "
    Private Sub AddTyping(ByVal strAdd As String)
        strTyping = strTyping.Remove(0, 1)
        strTyping = strTyping + strAdd
    End Sub
    Private Function GetTyping(ByVal intGet As Integer) As String
        Return strTyping.Substring(strTyping.Length - intGet, 1)
    End Function
    Private Function GetTypings(ByVal intGet As Integer) As String
        Return strTyping.Substring(strTyping.Length - intGet, intGet)
    End Function
    Private Sub IsUpper(ByVal cInput As Char)
        For Each cTemp As Char In strOriginal
            If (cTemp = Char.ToLower(cInput)) Then
                bIsUpper = Char.IsUpper(cInput)
            End If
        Next
    End Sub

    Private Function Check() As Boolean
        Dim Count As Integer
        Try
            If (rtxtMain.SelectionStart = 0) Then Exit Function
            'Prefix
            Count = 0
            For Each strTemp1 As Char In strOriginal
                If (GetTyping(1).ToLower = strTemp1) Then
                    For Each strTemp2 As Char In strPrefix
                        If (strTemp2 = "") Then Exit For
                        If (GetTyping(2).ToLower = strTemp2) Then
                            rtxtMain.SelectionStart -= 2
                            rtxtMain.SelectionLength = 2
                            Changed = rtxtMain.SelectedText
                            If (bIsUpper) Then
                                rtxtMain.SelectedText = strSupersigno(Count).ToUpper()
                            Else
                                rtxtMain.SelectedText = strSupersigno(Count)
                            End If
                            cExcep = strTemp1
                            Return True
                        End If
                    Next
                End If
                Count += 1
            Next

            'SubFix
            Count = 0
            For Each strTemp1 As Char In strOriginal
                If (GetTyping(2).ToLower = strTemp1) Then
                    For Each strTemp2 As Char In strSuffix
                        If (strTemp2 = "") Then Exit For
                        If (GetTyping(1).ToLower = strTemp2) Then
                            rtxtMain.SelectionStart -= 2
                            rtxtMain.SelectionLength = 2
                            Changed = rtxtMain.SelectedText
                            If (bIsUpper) Then
                                rtxtMain.SelectedText = strSupersigno(Count).ToUpper()
                            Else
                                rtxtMain.SelectedText = strSupersigno(Count)
                            End If
                            cExcep = strTemp2
                            Return True
                        End If
                    Next
                End If
                Count += 1
            Next

            'Excep
            Count = 0
            For Each strTemp1 As String In strExcep
                If strTemp1 = "" Then Exit For
                If (GetTypings(strTemp1.Length).ToLower = strTemp1) Then
                    For Each cTemp1 As Char In GetTypings(strTemp1.Length)
                        If (Char.IsLower(cTemp1) Xor Char.IsUpper(cTemp1)) Then
                            bIsUpper = Char.IsUpper(cTemp1)
                        End If
                    Next
                    rtxtMain.SelectionStart -= strTemp1.Length
                    rtxtMain.SelectionLength = strTemp1.Length
                    Changed = rtxtMain.SelectedText
                    If (bIsUpper) Then
                        rtxtMain.SelectedText = strExcepTo(Count).ToUpper
                    Else
                        rtxtMain.SelectedText = strExcepTo(Count)
                    End If
                    cExcep = strTemp1.Substring(strTemp1.Length - 1, 1)
                    Return True
                End If
                Count += 1
            Next
        Catch ex As Exception
        End Try
        Return False
    End Function
    Private Sub DirectCheck()
        Dim Count As Integer = 0
        For Each cTemp1 As Char In cDirect
            If (cTemp1 = GetTyping(1).ToLower) Then
                rtxtMain.SelectionStart -= 1
                rtxtMain.SelectionLength = 1
                Changed = rtxtMain.SelectedText
                If (Char.IsUpper(GetTyping(1))) Then
                    rtxtMain.SelectedText = strSupersigno(Count).ToUpper()
                Else
                    rtxtMain.SelectedText = strSupersigno(Count)
                End If
                If Not (cDirectExcep = "") Then
                    cExcep = cDirectExcep
                End If
                Exit Sub
            End If
            Count += 1
        Next

    End Sub
    Private Sub RecoverCheck()
        If (Changed = "") Or (cExcep = "") Then Exit Sub
        If rtxtMain.SelectionStart < 2 Then Exit Sub
        If (cExcep.ToString.ToLower = GetTyping(1).ToLower) Then
            rtxtMain.SelectionStart -= 2
            rtxtMain.SelectionLength = 2
            rtxtMain.SelectedText = Changed
            Changed = ""
            cExcep = ""
        End If
    End Sub
#End Region 'Prosidures for Input Supersigno
#Region " MenuItems to Select Input Method "
    Private Sub MenuItem35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem35.Click
        MenuItem34.Checked = False
        MenuItem35.Checked = True
        MenuItem36.Checked = False
        MenuItem37.Checked = False
        MenuItem40.Checked = False
        intSelectedMenu = 1

        strPrefix(0) = "^"
        strPrefix(1) = "'"
        strPrefix(2) = ";"
        strPrefix(3) = "/"
        strSuffix(0) = "x"
        strSuffix(1) = "h"
        strSuffix(2) = "^"
        strSuffix(3) = "'"
        strExcep(0) = "w"
        strExcep(1) = "~u"
        strExcep(2) = "u~"
        strExcep(3) = ""
        strExcepTo(0) = "ŭ"
        strExcepTo(1) = "ŭ"
        strExcepTo(2) = "ŭ"
        strExcepTo(3) = ""
        bDirect = False
        bRecoverable = True

    End Sub

    Private Sub MenuItem36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem36.Click
        MenuItem34.Checked = False
        MenuItem35.Checked = False
        MenuItem36.Checked = True
        MenuItem37.Checked = False
        MenuItem40.Checked = False
        intSelectedMenu = 2

        strPrefix(0) = ""
        strPrefix(1) = ""
        strPrefix(2) = ""
        strPrefix(3) = ""
        strSuffix(0) = "x"
        strSuffix(1) = ""
        strSuffix(2) = ""
        strSuffix(3) = ""
        strExcep(0) = ""
        strExcep(1) = ""
        strExcep(2) = ""
        strExcep(3) = ""
        strExcepTo(0) = ""
        strExcepTo(1) = ""
        strExcepTo(2) = ""
        strExcepTo(3) = ""
        bDirect = False
        bRecoverable = True

    End Sub

    Private Sub MenuItem37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem37.Click
        MenuItem34.Checked = False
        MenuItem35.Checked = False
        MenuItem36.Checked = False
        MenuItem37.Checked = True
        MenuItem40.Checked = False
        intSelectedMenu = 3

        strPrefix(0) = ""
        strPrefix(1) = ""
        strPrefix(2) = ""
        strPrefix(3) = ""
        strSuffix(0) = "h"
        strSuffix(1) = ""
        strSuffix(2) = ""
        strSuffix(3) = ""
        strExcep(0) = "w"
        strExcep(1) = ""
        strExcep(2) = ""
        strExcep(3) = ""
        strExcepTo(0) = "ŭ"
        strExcepTo(1) = ""
        strExcepTo(2) = ""
        strExcepTo(3) = ""
        bDirect = False
        bRecoverable = True

    End Sub

    Private Sub MenuItem40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem40.Click
        MenuItem34.Checked = False
        MenuItem35.Checked = False
        MenuItem36.Checked = False
        MenuItem37.Checked = False
        MenuItem40.Checked = True
        intSelectedMenu = 4

        strPrefix(0) = ""
        strPrefix(1) = ""
        strPrefix(2) = ""
        strPrefix(3) = ""
        strSuffix(0) = ""
        strSuffix(1) = ""
        strSuffix(2) = ""
        strSuffix(3) = ""
        strExcep(0) = ""
        strExcep(1) = ""
        strExcep(2) = ""
        strExcep(3) = ""
        strExcepTo(0) = ""
        strExcepTo(1) = ""
        strExcepTo(2) = ""
        strExcepTo(3) = ""
        bDirect = False
        bRecoverable = True

    End Sub

    Private Sub MenuItem34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem34.Click
        MenuItem34.Checked = True
        MenuItem35.Checked = False
        MenuItem36.Checked = False
        MenuItem37.Checked = False
        MenuItem40.Checked = False
        intSelectedMenu = 0

        Dim frmMeth As New frmMethod
        frmMeth.TextBox1.Text = strPrefix(0)
        frmMeth.TextBox2.Text = strPrefix(1)
        frmMeth.TextBox3.Text = strPrefix(2)
        frmMeth.TextBox4.Text = strPrefix(3)
        frmMeth.TextBox5.Text = strSuffix(0)
        frmMeth.TextBox6.Text = strSuffix(1)
        frmMeth.TextBox7.Text = strSuffix(2)
        frmMeth.TextBox8.Text = strSuffix(3)
        frmMeth.TextBox9.Text = strExcep(0)
        frmMeth.TextBox10.Text = strExcep(1)
        frmMeth.TextBox11.Text = strExcep(2)
        frmMeth.TextBox12.Text = strExcep(3)
        frmMeth.TextBox13.Text = strExcepTo(0)
        frmMeth.TextBox14.Text = strExcepTo(1)
        frmMeth.TextBox15.Text = strExcepTo(2)
        frmMeth.TextBox16.Text = strExcepTo(3)
        frmMeth.TextBox17.Text = cDirect(0)
        frmMeth.TextBox18.Text = cDirect(1)
        frmMeth.TextBox19.Text = cDirect(2)
        frmMeth.TextBox20.Text = cDirect(3)
        frmMeth.TextBox21.Text = cDirect(4)
        frmMeth.TextBox22.Text = cDirect(5)
        frmMeth.TextBox23.Text = cDirectExcep
        frmMeth.CheckBox1.Checked = Me.bDirect
        frmMeth.CheckBox2.Checked = Me.bRecoverable
        frmMeth.ShowDialog()
        If frmMeth.bIsOK Then
            strPrefix(0) = frmMeth.TextBox1.Text.ToLower
            strPrefix(1) = frmMeth.TextBox2.Text.ToLower
            strPrefix(2) = frmMeth.TextBox3.Text.ToLower
            strPrefix(3) = frmMeth.TextBox4.Text.ToLower
            strSuffix(0) = frmMeth.TextBox5.Text.ToLower
            strSuffix(1) = frmMeth.TextBox6.Text.ToLower
            strSuffix(2) = frmMeth.TextBox7.Text.ToLower
            strSuffix(3) = frmMeth.TextBox8.Text.ToLower
            strExcep(0) = frmMeth.TextBox9.Text.ToLower
            strExcep(1) = frmMeth.TextBox10.Text.ToLower
            strExcep(2) = frmMeth.TextBox11.Text.ToLower
            strExcep(3) = frmMeth.TextBox12.Text.ToLower
            strExcepTo(0) = frmMeth.TextBox13.Text.ToLower
            strExcepTo(1) = frmMeth.TextBox14.Text.ToLower
            strExcepTo(2) = frmMeth.TextBox15.Text.ToLower
            strExcepTo(3) = frmMeth.TextBox16.Text.ToLower
            cDirect(0) = frmMeth.TextBox17.Text.ToLower
            cDirect(1) = frmMeth.TextBox18.Text.ToLower
            cDirect(2) = frmMeth.TextBox19.Text.ToLower
            cDirect(3) = frmMeth.TextBox20.Text.ToLower
            cDirect(4) = frmMeth.TextBox21.Text.ToLower
            cDirect(5) = frmMeth.TextBox22.Text.ToLower
            cDirectExcep = frmMeth.TextBox23.Text.ToLower
            Me.bDirect = frmMeth.CheckBox1.Checked
            Me.bRecoverable = frmMeth.CheckBox2.Checked
        End If
    End Sub
#End Region
#Region " Setting - Save and Load "
    Public Sub SaveSetting()
        Try
            Dim saveformat As New SaveFormat
            saveformat.strPrefix = Me.strPrefix
            saveformat.strSuffix = Me.strSuffix
            saveformat.strExcep = Me.strExcep
            saveformat.strExcepTo = Me.strExcepTo
            saveformat.cDirect = Me.cDirect
            saveformat.cDirectExcep = Me.cDirectExcep
            saveformat.bDirect = Me.bDirect
            saveformat.intSelectedMenu = Me.intSelectedMenu
            saveformat.bRecoverable = Me.bRecoverable
            saveformat.bSaveSetting = Me.MenuItem43.Checked
            saveformat.bStatusBar = Me.MenuItem30.Checked
            saveformat.fntFont = Me.FontDialog1.Font.ToString
            saveformat.save()
        Catch ex As Exception

        End Try

    End Sub
    Public Sub LoadSetting()
        Try
            Dim saveformatt As New SaveFormat
            saveformatt = Supersignilo.SaveSetting.Load()
            If (saveformatt Is Nothing) Then Exit Sub
            Me.strPrefix = saveformatt.strPrefix
            Me.strSuffix = saveformatt.strSuffix
            Me.strExcep = saveformatt.strExcep
            Me.strExcepTo = saveformatt.strExcepTo
            Me.cDirectExcep = saveformatt.cDirectExcep
            Me.cDirect = saveformatt.cDirect
            Me.bDirect = saveformatt.bDirect
            Me.intSelectedMenu = saveformatt.intSelectedMenu
            Me.bRecoverable = saveformatt.bRecoverable
            Me.MenuItem43.Checked = saveformatt.bSaveSetting
            Me.MenuItem30.Checked = saveformatt.bStatusBar
            Me.StatusBar1.Visible = saveformatt.bStatusBar
            'Me.FontDialog1.Font = New System.Drawing.Font(saveformatt.fntFont

            MenuItem34.Checked = (intSelectedMenu = 0)
            MenuItem35.Checked = (intSelectedMenu = 1)
            MenuItem36.Checked = (intSelectedMenu = 2)
            MenuItem37.Checked = (intSelectedMenu = 3)
            MenuItem40.Checked = (intSelectedMenu = 4)
        Catch ex As Exception
        End Try
    End Sub
#End Region
#Region " About Supersigno "
    Private Sub rtxtMain_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles rtxtMain.KeyPress
        If (e.KeyChar = "") Then Exit Sub
        IsUpper(e.KeyChar)
        AddTyping(e.KeyChar)
    End Sub

    Private Sub rtxtMain_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles rtxtMain.KeyUp
        If Check() Then strTyping = "     "
        If (bDirect) Then
            DirectCheck()
        End If
        If (bRecoverable) Then
            RecoverCheck()
        End If
    End Sub

    Private Sub MenuItem42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem42.Click

        Dim strTemp As String = rtxtMain.Text
        Dim strName As String = Me.Text
        rtxtMain.Text = ""
        Dim intTempLen = strTemp.Length - 1
        For Count As Integer = 0 To intTempLen

            IsUpper(strTemp.Substring(Count, 1))
            AddTyping(strTemp.Substring(Count, 1))

            rtxtMain.SelectedText = strTemp.Substring(Count, 1)
            Application.DoEvents()
            rtxtMain.SelectionStart = Count + 1
            If Check() Then strTyping = "     "
            If (bDirect) Then
                DirectCheck()
            End If
            If (bRecoverable) Then
                RecoverCheck()
            End If
            Me.Text = "[ " & String.Format("{0:n1}", Count / intTempLen * 100) & "% ]"
        Next
        Me.Text = strName

    End Sub

    Private Sub MenuItem41_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem41.Click
        Dim frmM As New frmMal
        frmM.ShowDialog()
        If frmM.bIsOK Then
            rtxtMain.Text = rtxtMain.Text.Replace("ĉ", frmM.TextBox1.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("ĝ", frmM.TextBox2.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("ĥ", frmM.TextBox3.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("ĵ", frmM.TextBox4.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("ŭ", frmM.TextBox5.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("ŝ", frmM.TextBox6.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("Ĉ", frmM.TextBox7.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("Ĝ", frmM.TextBox8.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("Ĥ", frmM.TextBox9.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("Ĵ", frmM.TextBox10.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("Ŭ", frmM.TextBox11.Text)
            rtxtMain.Text = rtxtMain.Text.Replace("Ŝ", frmM.TextBox12.Text)
        End If
    End Sub
#End Region

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadSetting()
        Me.Text = strSoftname & " - " & strFileName
        Me.StatusBar1.Text = "Linio : " & rtxtMain.GetLineFromCharIndex(rtxtMain.SelectionStart) + 1

        If System.Environment.GetCommandLineArgs().Length > 1 Then
            OpenFileDialog1.FileName = System.Environment.GetCommandLineArgs()(1).ToString
            OpenFile()
        End If
        rtxtMain.Font = FontDialog1.Font
    End Sub

    Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If MenuItem43.Checked Then SaveSetting()
    End Sub

#Region " File Menu "

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim sLeftMargin As Single = e.MarginBounds.Left
        Dim sTopMargin As Single = e.MarginBounds.Top
        Dim fFont As Font = _
            New Font(rtxtMain.Font.Name, rtxtMain.Font.Size)


        e.Graphics.DrawString(rtxtMain.Text, fFont, Brushes.Black, sLeftMargin, sTopMargin)
    End Sub

    Private Sub SaveFile(ByVal strPath As String)
        'SaveFile Method in Version 0.2
        'Dim fileinfo As New System.IO.FileInfo(strPath)
        'Dim filetxt As System.IO.FileStream
        'Dim enc As System.Text.Encoding = System.Text.Encoding.UTF8

        'If (Not (IsNothing(fileinfo))) Then
        '    fileinfo.Delete()
        'End If

        'filetxt = System.IO.File.Open(strPath, IO.FileMode.OpenOrCreate)
        'filetxt.Write(enc.GetBytes(rtxtMain.Text), 0, enc.GetByteCount(rtxtMain.Text))
        'filetxt.Close()

        Dim strTemp As String
        strTemp = rtxtMain.Text
        Dim objWriter As System.IO.StreamWriter = New System.IO.StreamWriter(strPath, False)
        objWriter.Write(strTemp)
        objWriter.Close()
        objWriter = Nothing
    End Sub
    Private Sub OpenFile()
        Try
            If OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.Length - 4).ToLower = ".rtf" Then
                rtxtMain.LoadFile(OpenFileDialog1.FileName)
            Else
                Dim fileTxt As System.IO.FileStream
                Dim enc As System.Text.Encoding = System.Text.Encoding.UTF8
                fileTxt = System.IO.File.Open(OpenFileDialog1.FileName, IO.FileMode.Open)
                Dim bytes(fileTxt.Length() + 1) As Byte
                fileTxt.Read(bytes, 0, fileTxt.Length())
                rtxtMain.Text = enc.GetString(bytes)
                fileTxt.Close()
                strFilePath = OpenFileDialog1.FileName
                strFileName = strFilePath.Substring(strFilePath.LastIndexOf("\"), strFilePath.Length() - strFilePath.LastIndexOf("\"))
                strFileName = strFileName.Remove(0, 1)
                Me.Text = strSoftname & " - " & strFileName
            End If
        Catch ex As Exception
        End Try
        strMalfaru = rtxtMain.Text
    End Sub
    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        rtxtMain.Text = ""
        strMalfaru = ""
        strFileName = "Nova Dosiero"
        strFilePath = ""
        Me.Text = strSoftname & " - " & strFileName
    End Sub
    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        OpenFileDialog1.ShowDialog()
        OpenFile()
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        If strFilePath = "" Then
            Call MenuItem5_Click(sender, e)
        Else
            If strFilePath.Substring(strFilePath.Length - 4).ToLower = ".rtf" Then
                rtxtMain.SaveFile(strFilePath)
            Else
                SaveFile(strFilePath)
            End If

        End If
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        If strFilePath = "" Then
            SaveFileDialog1.FileName = strFileName & ".txt"
        Else
            Dim strDir As String = strFilePath.Substring(0, strFilePath.LastIndexOf("\"))
            Dim strFile = strFilePath.Substring(strFilePath.LastIndexOf("\"), strFilePath.Length() - strFilePath.LastIndexOf("\"))
            strFile = strFile.remove(0, 1)
            SaveFileDialog1.InitialDirectory = strDir
            SaveFileDialog1.FileName = strFile
        End If
        SaveFileDialog1.ShowDialog()
        If SaveFileDialog1.FileName.Substring(SaveFileDialog1.FileName.Length - 4).ToLower = ".rtf" Then
            rtxtMain.SaveFile(SaveFileDialog1.FileName)
        Else
            SaveFile(SaveFileDialog1.FileName)
        End If
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        PageSetupDialog1.ShowDialog()
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        If (PrintDialog1.ShowDialog() = DialogResult.OK) Then PrintDocument1.Print()
    End Sub

    Private Sub MenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem9.Click
        Me.Close()
    End Sub
#End Region
#Region " Edit Menu "
    Private Sub MenuItem52_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem52.Click
        If (MessageBox.Show("Ĉu Vi Vere Volas Malfari Ĉion?", "Malfari Ĉion", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) = DialogResult.OK) Then
            rtxtMain.Text = strMalfaru
        End If

    End Sub
    Private Sub MenuItem43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem43.Click
        MenuItem43.Checked = Not (MenuItem43.Checked)
    End Sub

    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem12.Click
        rtxtMain.Undo()
    End Sub

    Private Sub MenuItem13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem13.Click
        Clipboard.SetDataObject(rtxtMain.SelectedText)
        rtxtMain.SelectedText = ""
    End Sub

    Private Sub MenuItem15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem15.Click
        Clipboard.SetDataObject(rtxtMain.SelectedText)
    End Sub

    Private Sub MenuItem16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem16.Click
        If (Clipboard.GetDataObject.GetDataPresent(DataFormats.Text)) Then
            rtxtMain.SelectedText = Clipboard.GetDataObject.GetData(DataFormats.Text, True)
        End If
    End Sub

    Private Sub MenuItem17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem17.Click
        rtxtMain.SelectedText = ""
    End Sub

    Private Sub MenuItem18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem18.Click
        Dim frmF As New frmFind
        frmF.frmM = Me
        frmF.Show()
    End Sub

    Private Sub MenuItem20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem20.Click
        Dim frmF As New frmFind
        frmF.frmM = Me
        frmF.TextBox1.Text = strFindWhat
        frmF.RadioButton1.Checked = bFindUp
        frmF.RadioButton2.Checked = Not (bFindUp)
        frmF.CheckBox1.Checked = Me.bCase
        frmF.Find()
    End Sub

    Private Sub MenuItem21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem21.Click
        Dim frmR As New frmReplace
        frmR.frmM = Me
        frmR.Show()
    End Sub

    Private Sub MenuItem22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem22.Click

        Dim frmG As New frmGoTo
        frmG.frmM = Me
        frmG.TextBox1.Text = intGoto
        frmG.Show()



    End Sub

    Private Sub MenuItem23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem23.Click
        rtxtMain.SelectAll()
    End Sub

    Private Sub MenuItem25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem25.Click
        rtxtMain.SelectedText = Now()
    End Sub
#End Region
#Region " Other Menu "

    Private Sub MenuItem28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem28.Click
        MenuItem28.Checked = Not (MenuItem28.Checked)
        rtxtMain.WordWrap = MenuItem28.Checked
    End Sub

    Private Sub MenuItem29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem29.Click
        FontDialog1.ShowDialog()
        rtxtMain.Font = FontDialog1.Font
    End Sub

    Private Sub MenuItem30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem30.Click
        MenuItem30.Checked = Not (MenuItem30.Checked)
        Me.StatusBar1.Visible = MenuItem30.Checked
    End Sub

    Private Sub MenuItem33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem33.Click
        Dim frmA As New frmAbout
        frmA.Show()
    End Sub
#End Region

    Private Sub rtxtMain_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles rtxtMain.GotFocus
        Me.StatusBar1.Text = "Linio : " & rtxtMain.GetLineFromCharIndex(rtxtMain.SelectionStart) + 1
    End Sub

    Private Sub rtxtMain_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rtxtMain.TextChanged
        Me.StatusBar1.Text = "Linio : " & rtxtMain.GetLineFromCharIndex(rtxtMain.SelectionStart) + 1
    End Sub

#Region " Context Menu "
    Private Sub MenuItem44_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem44.Click
        rtxtMain.Undo()
    End Sub

    Private Sub MenuItem45_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem45.Click
        Clipboard.SetDataObject(rtxtMain.SelectedText)
        rtxtMain.SelectedText = ""
    End Sub

    Private Sub MenuItem47_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem47.Click
        Clipboard.SetDataObject(rtxtMain.SelectedText)
    End Sub

    Private Sub MenuItem48_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem48.Click
        If (Clipboard.GetDataObject.GetDataPresent(DataFormats.Text)) Then
            rtxtMain.SelectedText = Clipboard.GetDataObject.GetData(DataFormats.Text, True)
        End If
    End Sub

    Private Sub MenuItem49_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem49.Click
        rtxtMain.SelectedText = ""
    End Sub

    Private Sub MenuItem50_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem50.Click
        rtxtMain.SelectAll()
    End Sub
#End Region


End Class
