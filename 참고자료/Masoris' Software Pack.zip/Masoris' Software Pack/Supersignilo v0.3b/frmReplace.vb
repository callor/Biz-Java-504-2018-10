Public Class frmReplace
    Inherits System.Windows.Forms.Form

#Region " Windows Form 디자이너에서 생성한 코드 "

    Public Sub New()
        MyBase.New()

        '이 호출은 Windows Form 디자이너에 필요합니다.
        InitializeComponent()

        'InitializeComponent()를 호출한 다음에 초기화 작업을 추가하십시오.

    End Sub

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    'Windows Form 디자이너를 사용하여 수정할 수 있습니다.  
    '코드 편집기를 사용하여 수정하지 마십시오.
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents button4 As System.Windows.Forms.Button
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.checkBox1 = New System.Windows.Forms.CheckBox
        Me.button4 = New System.Windows.Forms.Button
        Me.button3 = New System.Windows.Forms.Button
        Me.button2 = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'checkBox1
        '
        Me.checkBox1.Location = New System.Drawing.Point(8, 80)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(112, 32)
        Me.checkBox1.TabIndex = 15
        Me.checkBox1.Text = "Ŝaku Majusko kaj Minusklo (&C)"
        '
        'button4
        '
        Me.button4.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.button4.Location = New System.Drawing.Point(264, 104)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(96, 23)
        Me.button4.TabIndex = 14
        Me.button4.Text = "Nuligu"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(264, 72)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(96, 21)
        Me.button3.TabIndex = 13
        Me.button3.Text = "Sanĝu Ĉiujn(&A)"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(264, 40)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(96, 22)
        Me.button2.TabIndex = 12
        Me.button2.Text = "Sanĝu (&R)"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(264, 8)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(96, 23)
        Me.button1.TabIndex = 11
        Me.button1.Text = "Serĉu Plu (&F)"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(72, 40)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(184, 20)
        Me.textBox2.TabIndex = 9
        Me.textBox2.Text = ""
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(72, 16)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(184, 20)
        Me.textBox1.TabIndex = 7
        Me.textBox1.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 40)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(69, 16)
        Me.label2.TabIndex = 10
        Me.label2.Text = "Al Kio (&P):"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(75, 17)
        Me.label1.TabIndex = 8
        Me.label1.Text = "Kion (&N):"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Location = New System.Drawing.Point(128, 72)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(128, 48)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Al Kie"
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(8, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(48, 16)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Sure"
        '
        'RadioButton2
        '
        Me.RadioButton2.Checked = True
        Me.RadioButton2.Location = New System.Drawing.Point(64, 24)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(56, 16)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Sube"
        '
        'frmReplace
        '
        Me.AcceptButton = Me.button2
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.button4
        Me.ClientSize = New System.Drawing.Size(368, 136)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.checkBox1)
        Me.Controls.Add(Me.button4)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmReplace"
        Me.Text = "Sanĝu"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public frmM As frmMain

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim frmF As New frmFind
        frmF.frmM = frmM
        frmF.TextBox1.Text = textBox1.Text
        frmF.RadioButton1.Checked = RadioButton1.Checked
        frmF.RadioButton2.Checked = RadioButton2.Checked
        frmF.CheckBox1.Checked = Me.checkBox1.Checked
        frmF.Find()
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Call button1_Click(sender, e)
        frmM.rtxtMain.SelectedText = textBox2.Text
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        Dim dTemp As Boolean
        Do
            Dim frmF As New frmFind
            frmF.frmM = frmM
            frmF.TextBox1.Text = textBox1.Text
            frmF.RadioButton1.Checked = RadioButton1.Checked
            frmF.RadioButton2.Checked = RadioButton2.Checked
            frmF.CheckBox1.Checked = Me.checkBox1.Checked
            dTemp = frmF.Find()
            frmM.rtxtMain.SelectedText = textBox2.Text
        Loop While Not (dTemp)
    End Sub

    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button4.Click
        Me.Close()
    End Sub
End Class
