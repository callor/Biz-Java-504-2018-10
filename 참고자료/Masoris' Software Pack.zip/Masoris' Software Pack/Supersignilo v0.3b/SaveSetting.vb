Imports System.IO
Imports System.Xml.Serialization
Public Class SaveSetting
    Public Function save() As Boolean
        Try
            Dim tempFileInfo As New FileInfo(Environment.CurrentDirectory & "\Supersignilo.xml")
            If (tempFileInfo.Exists) Then tempFileInfo.Delete()

            Dim stream As New FileStream(Environment.CurrentDirectory & "\Supersignilo.xml", FileMode.Create)
            Dim serializer As New XmlSerializer(Me.GetType)
            serializer.Serialize(stream, Me)
            stream.Close()

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Shared Function Load() As Object
        Dim fileinfo As New FileInfo(Environment.CurrentDirectory & "\Supersignilo.xml")
        If fileinfo.Exists = False Then Return Nothing
        Dim stream As New FileStream(Environment.CurrentDirectory & "\Supersignilo.xml", FileMode.Open)
        Dim serializer As New XmlSerializer(GetType(SaveFormat))
        Dim newObject As Object = serializer.Deserialize(stream)
        stream.Close()
        Return newObject
    End Function
End Class

Public Class SaveFormat
    Inherits SaveSetting
    Public strPrefix(4) As String
    Public strSuffix(4) As String
    Public strExcep(4) As String
    Public strExcepTo(4) As String
    Public cDirect(6) As String
    Public cDirectExcep As String
    Public bDirect As Boolean
    Public intSelectedMenu As Integer
    Public bRecoverable As Boolean
    Public bSaveSetting As Boolean
    Public bStatusBar As Boolean
    Public fntFont As String
End Class